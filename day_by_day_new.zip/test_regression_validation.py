import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

from regression_validation import (
    RegressionValidationConfig,
    _discrete_bucket_labels,
    _stability_block_light,
    _test_mean_equality,
    _test_metric_stability,
    load_frame,
    make_validation_frame,
    predict_with_model,
    validate_regression_model,
    validate_regression_model_from_files,
)


def _synthetic_frames(seed=42):
    rng = np.random.default_rng(seed)

    def make_part(n, shift=0.0):
        x1 = rng.normal(loc=shift, scale=1.0, size=n)
        x2 = rng.integers(0, 4, size=n)
        cat = rng.choice(["a", "b", "c"], size=n, p=[0.55, 0.30, 0.15])
        noise = rng.normal(0, 0.25, size=n)
        y = np.maximum(0.0, 1.2 + 0.8 * x1 + 0.25 * x2 + noise)
        pred = np.maximum(0.0, y + rng.normal(0, 0.22, size=n))
        return pd.DataFrame({"x1": x1, "x2": x2, "cat": cat, "target": y, "prediction": pred})

    return make_part(260, 0.0), make_part(120, 0.05), make_part(110, 0.18)


def _fast_config():
    return RegressionValidationConfig(
        primary_metric="mae",
        split_n_random=3,
        split_cv_splits=3,
        split_sample_size=500,
        psi_sample_size=500,
        bootstrap_n=30,
        bootstrap_sample_size=500,
        vif_sample_size=500,
        vif_max_features=10,
    )


class RegressionValidationTests(unittest.TestCase):
    def test_methodology_defaults_do_not_sample_or_cap(self):
        cfg = RegressionValidationConfig()
        self.assertEqual(cfg.split_n_random, 200)
        self.assertIsNone(cfg.split_sample_size)
        self.assertIsNone(cfg.psi_sample_size)
        self.assertIsNone(cfg.bootstrap_sample_size)
        self.assertIsNone(cfg.vif_sample_size)
        self.assertIsNone(cfg.vif_max_features)
        self.assertIsNone(cfg.max_single_feature_baselines)

    def test_validation_report_is_created(self):
        train, oos, oot = _synthetic_frames()
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "report.xlsx"
            result = validate_regression_model(
                train_df=train,
                oos_df=oos,
                oot_df=oot,
                model_name="synthetic_predictions",
                feature_cols=["x1", "x2", "cat"],
                output_path=output,
                config=_fast_config(),
            )
            self.assertTrue(output.exists())
            self.assertIn(result.overall_light, {"green", "yellow", "red"})
            self.assertGreaterEqual(len(result.test_summary), 11)
            self.assertIn("T2_1_baselines", result.details)
            self.assertIn("T4_3_regression_ftest", result.details)

    def test_from_files_parquet_and_pickle(self):
        train, oos, oot = _synthetic_frames(seed=7)
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            train_path = tmp / "train.parquet"
            oos_path = tmp / "oos.pkl"
            oot_path = tmp / "oot.parquet"
            train.to_parquet(train_path)
            oos.to_pickle(oos_path)
            oot.to_parquet(oot_path)
            output = tmp / "from_files.xlsx"
            result = validate_regression_model_from_files(
                train_path=train_path,
                oos_path=oos_path,
                oot_path=oot_path,
                model_name="from_files",
                feature_cols=["x1", "x2", "cat"],
                output_path=output,
                config=_fast_config(),
            )
            self.assertTrue(output.exists())
            self.assertEqual(load_frame(train_path).shape[0], train.shape[0])
            self.assertIn("T1_2_feature_psi", result.details)

    def test_from_files_with_joblib_model_path(self):
        try:
            import joblib
        except ImportError:
            self.skipTest("joblib is not installed")

        train, oos, oot = _synthetic_frames(seed=8)
        feature_cols = ["x1", "x2"]
        model = RandomForestRegressor(n_estimators=20, random_state=8, min_samples_leaf=5)
        model.fit(train[feature_cols], train["target"])
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            train_path = tmp / "train.parquet"
            oos_path = tmp / "oos.parquet"
            oot_path = tmp / "oot.parquet"
            model_path = tmp / "rf.joblib"
            train.drop(columns=["prediction"]).to_parquet(train_path)
            oos.drop(columns=["prediction"]).to_parquet(oos_path)
            oot.drop(columns=["prediction"]).to_parquet(oot_path)
            joblib.dump(model, model_path)
            output = tmp / "from_files_model.xlsx"
            result = validate_regression_model_from_files(
                train_path=train_path,
                oos_path=oos_path,
                oot_path=oot_path,
                model_name="from_files_joblib_model",
                model_path=model_path,
                feature_cols=feature_cols,
                output_path=output,
                config=_fast_config(),
            )
            self.assertTrue(output.exists())
            self.assertIn(result.overall_light, {"green", "yellow", "red"})
            self.assertIn("metrics_by_split", result.details)

    def test_from_files_does_not_mutate_config_categorical_columns(self):
        train, oos, oot = _synthetic_frames(seed=13)
        cfg = _fast_config()
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            train_path = tmp / "train.parquet"
            oos_path = tmp / "oos.parquet"
            oot_path = tmp / "oot.parquet"
            train.to_parquet(train_path)
            oos.to_parquet(oos_path)
            oot.to_parquet(oot_path)
            validate_regression_model_from_files(
                train_path=train_path,
                oos_path=oos_path,
                oot_path=oot_path,
                model_name="from_files_with_cat",
                feature_cols=["x1", "x2", "cat"],
                categorical_cols=["cat"],
                config=cfg,
            )
            self.assertIsNone(cfg.categorical_cols)
            result = validate_regression_model_from_files(
                train_path=train_path,
                oos_path=oos_path,
                oot_path=oot_path,
                model_name="from_files_without_cat",
                feature_cols=["x1", "x2"],
                config=cfg,
            )
            self.assertIn(result.overall_light, {"green", "yellow", "red"})

    def test_none_sample_sizes_use_full_splits(self):
        train, oos, oot = _synthetic_frames(seed=9)
        cfg = _fast_config()
        cfg.split_sample_size = None
        cfg.psi_sample_size = None
        cfg.bootstrap_sample_size = None
        cfg.vif_sample_size = None
        result = validate_regression_model(
            train_df=train,
            oos_df=oos,
            oot_df=oot,
            model_name="full_sample_validation",
            feature_cols=["x1", "x2", "cat"],
            config=cfg,
        )
        split_detail = result.details["T1_1_split_quality"].iloc[0]
        self.assertEqual(int(split_detail["n_train"]), len(train))
        self.assertEqual(int(split_detail["n_oos"]), len(oos))
        ci_detail = result.details["T2_2_metric_ci"].set_index("split")
        self.assertEqual(int(ci_detail.loc["train", "sample_size"]), len(train))
        self.assertEqual(int(ci_detail.loc["test", "sample_size"]), len(oos))

    def test_missing_oot_makes_stability_block_yellow(self):
        train, oos, _ = _synthetic_frames(seed=12)
        result = validate_regression_model(
            train_df=train,
            oos_df=oos,
            oot_df=None,
            model_name="no_oot",
            feature_cols=["x1", "x2", "cat"],
            config=_fast_config(),
        )
        stability = result.block_summary[result.block_summary["block"].eq("Стабильность модели")]
        self.assertFalse(stability.empty)
        self.assertEqual(stability.iloc[0]["traffic_light_code"], "yellow")

    def test_baselines_follow_methodology_table(self):
        train, oos, oot = _synthetic_frames(seed=10)
        result = validate_regression_model(
            train_df=train,
            oos_df=oos,
            oot_df=oot,
            model_name="baseline_methodology",
            feature_cols=["x1", "x2", "cat"],
            config=_fast_config(),
        )
        baselines = set(result.details["T2_1_baselines"]["baseline"])
        self.assertIn("constant_mean_train", baselines)
        self.assertIn("ols_on:constant_mean_train", baselines)
        self.assertIn("feature_as_prediction:x1", baselines)
        self.assertIn("ols_on_feature:x1", baselines)
        self.assertNotIn("ols_all_features", baselines)

    def test_discrete_psi_uses_sequential_small_bucket_merging(self):
        cfg = _fast_config()
        train = pd.Series(
            ["a"] * 50 + ["b"] * 20 + ["c"] * 4 + ["d"] * 4 + ["e"] * 4
            + ["f"] * 4 + ["g"] * 4 + ["h"] * 4 + ["i"] * 3 + ["j"] * 3
        )
        compare = train.sample(frac=1.0, random_state=1).reset_index(drop=True)
        train_labels, compare_labels, n_buckets = _discrete_bucket_labels(train, compare, cfg)
        self.assertGreater(n_buckets, 3)
        for label in compare_labels[compare_labels != "__MISSING__"].unique():
            share = float((compare_labels == label).mean())
            self.assertGreaterEqual(share, cfg.psi_min_bucket_share)

    def test_mean_equality_boundary_thresholds_follow_methodology(self):
        cfg = _fast_config()
        y = np.ones(20)
        cases = [
            (np.full(20, 1.15), "green"),
            (np.full(20, 1.30), "yellow"),
            (np.full(20, 1.31), "red"),
        ]
        for pred, expected in cases:
            summary, _ = _test_mean_equality(
                y,
                pred,
                split_name="test",
                test_id="3.2",
                block="Калибровка модели",
                test_name="boundary",
                green_abs=0.15,
                yellow_abs=0.30,
                config=cfg,
            )
            self.assertEqual(summary["traffic_light_code"], expected)

    def test_stability_boundary_thresholds_follow_methodology(self):
        cfg = _fast_config()

        def light(compare_value):
            metrics = pd.DataFrame(
                [
                    {"split": "base", "primary_metric_value": 1.0},
                    {"split": "compare", "primary_metric_value": compare_value},
                ]
            )
            summary, _ = _test_metric_stability(
                metrics,
                "5.1",
                "base -> compare",
                "base",
                "compare",
                cfg,
            )
            return summary["traffic_light_code"]

        self.assertEqual(light(1.15), "green")
        self.assertEqual(light(1.20), "green")
        self.assertEqual(light(1.21), "yellow")
        self.assertEqual(light(1.31), "red")

    def test_stability_block_matrix_matches_methodology(self):
        def block_light(t51, other):
            part = pd.DataFrame(
                [
                    {"test_id": "5.1", "traffic_light_code": t51},
                    {"test_id": "5.2", "traffic_light_code": other},
                ]
            )
            return _stability_block_light(part)

        self.assertEqual(block_light("green", "green"), "green")
        self.assertEqual(block_light("yellow", "green"), "yellow")
        self.assertEqual(block_light("red", "green"), "red")
        self.assertEqual(block_light("green", "yellow"), "green")
        self.assertEqual(block_light("yellow", "yellow"), "yellow")
        self.assertEqual(block_light("red", "yellow"), "red")
        self.assertEqual(block_light("green", "red"), "yellow")
        self.assertEqual(block_light("yellow", "red"), "red")
        self.assertEqual(block_light("red", "red"), "red")

    def test_model_predict_interface(self):
        train, oos, oot = _synthetic_frames(seed=11)
        feature_cols = ["x1", "x2"]
        model = RandomForestRegressor(n_estimators=20, random_state=11, min_samples_leaf=5)
        model.fit(train[feature_cols], train["target"])
        train_no_pred = train.drop(columns=["prediction"])
        oos_no_pred = oos.drop(columns=["prediction"])
        oot_no_pred = oot.drop(columns=["prediction"])
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "model_predict.xlsx"
            result = validate_regression_model(
                train_df=train_no_pred,
                oos_df=oos_no_pred,
                oot_df=oot_no_pred,
                model_name="rf_predict",
                model=model,
                feature_cols=feature_cols,
                output_path=output,
                config=_fast_config(),
            )
            self.assertTrue(output.exists())
            self.assertIn("metrics_by_split", result.details)

    def test_catboost_predict_interface_when_available(self):
        try:
            from catboost import CatBoostRegressor
        except ImportError:
            self.skipTest("catboost is not installed")

        train, oos, oot = _synthetic_frames(seed=21)
        feature_cols = ["x1", "x2", "cat"]
        model = CatBoostRegressor(
            iterations=15,
            depth=3,
            learning_rate=0.08,
            loss_function="RMSE",
            random_seed=21,
            verbose=False,
            allow_writing_files=False,
        )
        model.fit(train[feature_cols], train["target"], cat_features=[2])
        train_no_pred = train.drop(columns=["prediction"])
        oos_no_pred = oos.drop(columns=["prediction"])
        oot_no_pred = oot.drop(columns=["prediction"])
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "catboost_predict.xlsx"
            result = validate_regression_model(
                train_df=train_no_pred,
                oos_df=oos_no_pred,
                oot_df=oot_no_pred,
                model_name="catboost_predict",
                model=model,
                feature_cols=feature_cols,
                output_path=output,
                config=_fast_config(),
            )
            self.assertTrue(output.exists())
            self.assertIn(result.overall_light, {"green", "yellow", "red"})

    def test_lightgbm_regressor_predict_interface_when_available(self):
        try:
            from lightgbm import LGBMRegressor
        except ImportError:
            self.skipTest("lightgbm is not installed")

        train, oos, oot = _synthetic_frames(seed=31)
        feature_cols = ["x1", "x2", "cat"]
        train_fit = train[feature_cols].copy()
        train_fit["cat"] = train_fit["cat"].astype("category")
        model = LGBMRegressor(
            n_estimators=25,
            learning_rate=0.08,
            num_leaves=15,
            min_child_samples=5,
            random_state=31,
            verbose=-1,
        )
        model.fit(train_fit, train["target"], categorical_feature=["cat"])
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "lightgbm_predict.xlsx"
            result = validate_regression_model(
                train_df=train.drop(columns=["prediction"]),
                oos_df=oos.drop(columns=["prediction"]),
                oot_df=oot.drop(columns=["prediction"]),
                model_name="lightgbm_predict",
                model=model,
                feature_cols=feature_cols,
                categorical_cols=["cat"],
                output_path=output,
                config=_fast_config(),
            )
            self.assertTrue(output.exists())
            self.assertIn("T4_4_vif", result.details)

    def test_reusing_config_does_not_leak_categorical_columns(self):
        train, oos, oot = _synthetic_frames(seed=32)
        cfg = _fast_config()
        result_1 = validate_regression_model(
            train_df=train,
            oos_df=oos,
            oot_df=oot,
            model_name="with_cat",
            feature_cols=["x1", "x2", "cat"],
            categorical_cols=["cat"],
            config=cfg,
        )
        self.assertIn(result_1.overall_light, {"green", "yellow", "red"})
        self.assertIsNone(cfg.categorical_cols)

        result_2 = validate_regression_model(
            train_df=train,
            oos_df=oos,
            oot_df=oot,
            model_name="without_cat",
            feature_cols=["x1", "x2"],
            config=cfg,
        )
        self.assertIn(result_2.overall_light, {"green", "yellow", "red"})

    def test_xgboost_regressor_and_booster_predict_interfaces_when_available(self):
        try:
            import xgboost as xgb
        except ImportError:
            self.skipTest("xgboost is not installed")

        train, oos, oot = _synthetic_frames(seed=41)
        feature_cols = ["x1", "x2"]
        model = xgb.XGBRegressor(
            n_estimators=25,
            max_depth=3,
            learning_rate=0.08,
            subsample=0.9,
            colsample_bytree=0.9,
            objective="reg:squarederror",
            random_state=41,
        )
        model.fit(train[feature_cols], train["target"])
        frames = {
            "train_df": train.drop(columns=["prediction"]),
            "oos_df": oos.drop(columns=["prediction"]),
            "oot_df": oot.drop(columns=["prediction"]),
        }
        with tempfile.TemporaryDirectory() as tmp:
            output_1 = Path(tmp) / "xgb_regressor.xlsx"
            result_1 = validate_regression_model(
                **frames,
                model_name="xgb_regressor",
                model=model,
                feature_cols=feature_cols,
                output_path=output_1,
                config=_fast_config(),
            )
            self.assertTrue(output_1.exists())
            self.assertIn(result_1.overall_light, {"green", "yellow", "red"})

            output_2 = Path(tmp) / "xgb_booster.xlsx"
            result_2 = validate_regression_model(
                **frames,
                model_name="xgb_booster",
                model=model.get_booster(),
                feature_cols=feature_cols,
                output_path=output_2,
                config=_fast_config(),
            )
            self.assertTrue(output_2.exists())
            self.assertIn("metrics_by_split", result_2.details)

    def test_xgboost_booster_predict_uses_best_iteration_attr_when_available(self):
        try:
            import xgboost as xgb
        except ImportError:
            self.skipTest("xgboost is not installed")

        train, _, _ = _synthetic_frames(seed=42)
        feature_cols = ["x1", "x2"]
        dtrain = xgb.DMatrix(train[feature_cols], label=train["target"])
        booster = xgb.train(
            {"objective": "reg:squarederror", "max_depth": 2, "eta": 0.25, "seed": 42},
            dtrain,
            num_boost_round=8,
        )
        booster.set_attr(best_iteration="2")
        actual = predict_with_model(booster, train[feature_cols])
        expected = booster.predict(xgb.DMatrix(train[feature_cols]), iteration_range=(0, 3))
        self.assertTrue(np.allclose(actual, expected))

    def test_primary_metric_choices(self):
        train, oos, oot = _synthetic_frames(seed=51)
        for metric in ("mae", "rmse", "mae_to_mean", "mae_to_min"):
            cfg = _fast_config()
            cfg.primary_metric = metric
            result = validate_regression_model(
                train_df=train,
                oos_df=oos,
                oot_df=oot,
                model_name=f"metric_{metric}",
                feature_cols=["x1", "x2", "cat"],
                config=cfg,
            )
            self.assertIn(result.overall_light, {"green", "yellow", "red"})

    def test_relative_metric_with_zero_mean_target_is_not_mis_scored(self):
        rng = np.random.default_rng(71)

        def make_part(n):
            x1 = rng.normal(size=n)
            y = np.tile([-1.0, 1.0], n // 2)
            pred = y + rng.normal(0, 0.2, size=n)
            return pd.DataFrame({"x1": x1, "target": y, "prediction": pred})

        train = make_part(80)
        oos = make_part(40)
        oot = make_part(40)
        cfg = _fast_config()
        cfg.primary_metric = "mae_to_mean"
        result = validate_regression_model(
            train_df=train,
            oos_df=oos,
            oot_df=oot,
            model_name="zero_mean_relative_metric",
            feature_cols=["x1"],
            config=cfg,
        )
        tests = result.test_summary.set_index("test_id")
        self.assertEqual(tests.loc["2.1", "traffic_light_code"], "gray")
        self.assertTrue(np.isnan(result.details["T2_2_metric_ci"].iloc[0]["metric_value"]))

    def test_ftest_is_gray_when_target_has_no_variance(self):
        rng = np.random.default_rng(72)

        def make_part(n):
            x1 = rng.normal(size=n)
            pred = rng.normal(0, 0.1, size=n)
            return pd.DataFrame({"x1": x1, "target": np.zeros(n), "prediction": pred})

        cfg = _fast_config()
        result = validate_regression_model(
            train_df=make_part(80),
            oos_df=make_part(40),
            oot_df=make_part(40),
            model_name="constant_target_ftest",
            feature_cols=["x1"],
            config=cfg,
        )
        tests = result.test_summary.set_index("test_id")
        self.assertEqual(tests.loc["4.3", "traffic_light_code"], "gray")

    def test_categorical_cols_force_discrete_psi_for_numeric_feature(self):
        train, oos, oot = _synthetic_frames(seed=61)
        cfg = _fast_config()
        cfg.categorical_cols = ["x1"]
        result = validate_regression_model(
            train_df=train,
            oos_df=oos,
            oot_df=oot,
            model_name="explicit_categorical",
            feature_cols=["x1", "x2", "cat"],
            config=cfg,
        )
        features = result.details["model_features"].set_index("feature")
        self.assertTrue(bool(features.loc["x1", "is_categorical"]))
        psi = result.details["T1_2_feature_psi"]
        x1_psi = psi[(psi["feature"] == "x1") & (psi["compare_split"] == "test")]
        self.assertEqual(x1_psi.iloc[0]["kind"], "discrete")

    def test_make_validation_frame(self):
        X = pd.DataFrame({"a": [1, 2, 3]})
        frame = make_validation_frame(X, [1.0, 2.0, 3.0], [0.9, 2.1, 2.8])
        self.assertEqual(list(frame.columns), ["a", "target", "prediction"])


if __name__ == "__main__":
    unittest.main()
