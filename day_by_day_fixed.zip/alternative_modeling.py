from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    mean_absolute_error,
    mean_squared_error,
    roc_auc_score,
)


def _as_array(values: Iterable[float]) -> np.ndarray:
    return np.asarray(values, dtype="float64")


def _predict_lgb(model: Any, X: pd.DataFrame) -> np.ndarray:
    best_iteration = getattr(model, "best_iteration", None) or None
    return np.asarray(model.predict(X, num_iteration=best_iteration), dtype="float64")


def _clip_prediction(pred: Iterable[float], y_reference: np.ndarray) -> np.ndarray:
    pred = np.asarray(pred, dtype="float64")
    pred = np.where(np.isfinite(pred), pred, 0.0)
    pred = np.maximum(pred, 0.0)
    finite_y = y_reference[np.isfinite(y_reference)]
    if finite_y.size and finite_y.min() >= 0 and finite_y.max() <= 1.0 + 1e-12:
        pred = np.minimum(pred, 1.0)
    return pred


def _mean_calibrate(
    pred_by_split: Dict[str, np.ndarray],
    y_val: np.ndarray,
    *,
    eps: float = 1e-12,
) -> tuple[Dict[str, np.ndarray], float]:
    pred_val_mean = float(np.nanmean(pred_by_split["val"]))
    if not np.isfinite(pred_val_mean) or pred_val_mean <= eps:
        return {k: v.copy() for k, v in pred_by_split.items()}, 1.0
    factor = float(np.nanmean(y_val)) / pred_val_mean
    return {k: _clip_prediction(v * factor, y_val) for k, v in pred_by_split.items()}, factor


def _safe_auc(y_true: np.ndarray, pred: np.ndarray, metric: str) -> float:
    event = (y_true > 0).astype(int)
    if np.unique(event).size < 2:
        return np.nan
    try:
        if metric == "roc_auc":
            return float(roc_auc_score(event, pred))
        if metric == "pr_auc":
            return float(average_precision_score(event, pred))
    except ValueError:
        return np.nan
    raise ValueError(metric)


def _top_lift(y_true: np.ndarray, pred: np.ndarray, top_share: float = 0.01) -> tuple[float, float]:
    event = (y_true > 0).astype(int)
    base_rate = float(event.mean())
    if len(event) == 0 or base_rate <= 0:
        return np.nan, np.nan
    n_top = max(1, int(np.ceil(len(event) * top_share)))
    top_idx = np.argsort(-pred)[:n_top]
    top_rate = float(event[top_idx].mean())
    return top_rate, top_rate / base_rate


def _metrics_rows(
    predictions: Dict[str, Dict[str, np.ndarray]],
    y_by_split: Dict[str, np.ndarray],
    *,
    calibration_factors: Optional[Dict[str, float]] = None,
) -> pd.DataFrame:
    rows = []
    for model_name, split_preds in predictions.items():
        for split, y_true in y_by_split.items():
            if split not in split_preds:
                continue
            pred = split_preds[split]
            mean_fact = float(np.nanmean(y_true))
            mean_pred = float(np.nanmean(pred))
            mae = float(mean_absolute_error(y_true, pred))
            rmse = float(np.sqrt(mean_squared_error(y_true, pred)))
            top_rate, top_lift = _top_lift(y_true, pred)
            rows.append(
                {
                    "model": model_name,
                    "split": split,
                    "rows": int(len(y_true)),
                    "mean_fact": mean_fact,
                    "mean_pred": mean_pred,
                    "fact_pred": mean_fact / mean_pred if mean_pred > 1e-12 else np.inf,
                    "MAE": mae,
                    "RMSE": rmse,
                    "MAE_to_mean": mae / mean_fact if mean_fact > 1e-12 else np.nan,
                    "Brier": float(mean_squared_error((y_true > 0).astype(int), pred)),
                    "ROC_AUC": _safe_auc(y_true, pred, "roc_auc"),
                    "PR_AUC": _safe_auc(y_true, pred, "pr_auc"),
                    "top_1pct_event_rate": top_rate,
                    "top_1pct_lift": top_lift,
                    "calibration_factor": (calibration_factors or {}).get(model_name, 1.0),
                }
            )
    return pd.DataFrame(rows)


def _save_report(path: Path, results_df: pd.DataFrame, notes: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    notes_df = pd.DataFrame({"note": notes})
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        results_df.to_excel(writer, sheet_name="metrics", index=False)
        notes_df.to_excel(writer, sheet_name="notes", index=False)


def build_alternative_models(
    *,
    X_train: pd.DataFrame,
    y_train: Iterable[float],
    X_val: pd.DataFrame,
    y_val: Iterable[float],
    X_test: pd.DataFrame,
    y_test: Iterable[float],
    X_oot: Optional[pd.DataFrame] = None,
    y_oot: Optional[Iterable[float]] = None,
    categorical_feature: Optional[List[int]] = None,
    feature_cols: Optional[List[str]] = None,
    target_col: str = "target",
    prediction_col: str = "prediction",
    artifacts_dir: str | Path = "artifacts/alternative_models",
    seed: int = 42,
    max_boost_rounds: int = 2000,
    early_stopping_rounds: int = 50,
    run_hurdle: bool = True,
    save_artifacts: bool = True,
) -> Dict[str, Any]:
    """Train zero-inflation-friendly alternatives for a non-negative regression target.

    The main alternative is a probability model for P(y > 0). For a binary or
    almost-binary target this probability is already the expected value. For a
    genuinely continuous non-negative target the optional hurdle model multiplies
    P(y > 0) by E(y | y > 0).
    """

    try:
        import lightgbm as lgb
    except ImportError as exc:
        raise ImportError("LightGBM is required for alternative model construction") from exc

    feature_cols = list(feature_cols or X_train.columns)
    categorical_feature = list(categorical_feature or [])
    artifacts_dir = Path(artifacts_dir)

    y_train = _as_array(y_train)
    y_val = _as_array(y_val)
    y_test = _as_array(y_test)
    y_by_split: Dict[str, np.ndarray] = {"train": y_train, "val": y_val, "test": y_test}
    X_by_split: Dict[str, pd.DataFrame] = {"train": X_train, "val": X_val, "test": X_test}
    if X_oot is not None and y_oot is not None:
        y_by_split["oot"] = _as_array(y_oot)
        X_by_split["oot"] = X_oot

    all_y = np.concatenate(list(y_by_split.values()))
    finite_y = all_y[np.isfinite(all_y)]
    is_binary_target = bool(
        finite_y.size
        and finite_y.min() >= 0
        and finite_y.max() <= 1.0 + 1e-12
        and np.all(np.isin(np.unique(finite_y), [0.0, 1.0]))
    )

    y_train_event = (y_train > 0).astype("int8")
    y_val_event = (y_val > 0).astype("int8")
    if np.unique(y_train_event).size < 2 or np.unique(y_val_event).size < 2:
        raise ValueError("Alternative binary model requires both zero and positive targets in train and val.")

    bin_params = {
        "objective": "binary",
        "metric": ["binary_logloss", "auc"],
        "learning_rate": 0.03,
        "num_leaves": 31,
        "max_depth": 5,
        "min_data_in_leaf": max(50, int(0.0005 * len(X_train))),
        "feature_fraction": 0.85,
        "bagging_fraction": 0.85,
        "bagging_freq": 5,
        "lambda_l1": 1.0,
        "lambda_l2": 10.0,
        "seed": seed,
        "verbosity": -1,
        "force_col_wise": True,
    }
    dtrain_bin = lgb.Dataset(
        X_train,
        label=y_train_event,
        categorical_feature=categorical_feature,
        free_raw_data=False,
    )
    dval_bin = lgb.Dataset(
        X_val,
        label=y_val_event,
        categorical_feature=categorical_feature,
        reference=dtrain_bin,
        free_raw_data=False,
    )
    lgb_binary = lgb.train(
        bin_params,
        dtrain_bin,
        num_boost_round=max_boost_rounds,
        valid_sets=[dval_bin],
        valid_names=["val"],
        callbacks=[
            lgb.early_stopping(early_stopping_rounds, verbose=False),
            lgb.log_evaluation(100),
        ],
    )

    predictions: Dict[str, Dict[str, np.ndarray]] = {}
    calibration_factors: Dict[str, float] = {}

    binary_preds = {
        split: _clip_prediction(_predict_lgb(lgb_binary, X), y_by_split[split])
        for split, X in X_by_split.items()
    }
    predictions["alt_lgb_binary_prob"] = binary_preds
    calibration_factors["alt_lgb_binary_prob"] = 1.0

    binary_cal_preds, binary_k = _mean_calibrate(binary_preds, y_val)
    predictions["alt_lgb_binary_prob_valcal"] = binary_cal_preds
    calibration_factors["alt_lgb_binary_prob_valcal"] = binary_k

    mean_train = float(np.nanmean(y_train))
    predictions["alt_constant_train_mean"] = {
        split: np.full(len(y), mean_train, dtype="float64")
        for split, y in y_by_split.items()
    }
    calibration_factors["alt_constant_train_mean"] = 1.0

    models: Dict[str, Any] = {"alt_lgb_binary_prob": lgb_binary}
    notes = [
        "alt_lgb_binary_prob predicts P(target > 0); no class weights are used, so probabilities are not distorted by rebalancing.",
        "alt_lgb_binary_prob_valcal applies one validation mean-calibration factor and clips predictions to the feasible non-negative range.",
        "alt_constant_train_mean is a sanity baseline: every row receives the train target mean.",
    ]

    if run_hurdle:
        if is_binary_target:
            predictions["alt_lgb_hurdle"] = {k: v.copy() for k, v in binary_preds.items()}
            predictions["alt_lgb_hurdle_valcal"] = {k: v.copy() for k, v in binary_cal_preds.items()}
            calibration_factors["alt_lgb_hurdle"] = 1.0
            calibration_factors["alt_lgb_hurdle_valcal"] = binary_k
            notes.append("Target is binary, so the hurdle expected value equals P(target > 0).")
        else:
            train_pos = y_train > 0
            val_pos = y_val > 0
            if int(train_pos.sum()) >= 100 and int(val_pos.sum()) >= 20:
                pos_params = {
                    "objective": "regression_l1",
                    "metric": "mae",
                    "learning_rate": 0.03,
                    "num_leaves": 31,
                    "max_depth": 5,
                    "min_data_in_leaf": max(20, int(0.001 * train_pos.sum())),
                    "feature_fraction": 0.85,
                    "bagging_fraction": 0.85,
                    "bagging_freq": 5,
                    "lambda_l1": 1.0,
                    "lambda_l2": 10.0,
                    "seed": seed,
                    "verbosity": -1,
                    "force_col_wise": True,
                }
                dtrain_pos = lgb.Dataset(
                    X_train.loc[train_pos],
                    label=y_train[train_pos],
                    categorical_feature=categorical_feature,
                    free_raw_data=False,
                )
                dval_pos = lgb.Dataset(
                    X_val.loc[val_pos],
                    label=y_val[val_pos],
                    categorical_feature=categorical_feature,
                    reference=dtrain_pos,
                    free_raw_data=False,
                )
                lgb_positive = lgb.train(
                    pos_params,
                    dtrain_pos,
                    num_boost_round=max_boost_rounds,
                    valid_sets=[dval_pos],
                    valid_names=["val_positive"],
                    callbacks=[
                        lgb.early_stopping(early_stopping_rounds, verbose=False),
                        lgb.log_evaluation(100),
                    ],
                )
                models["alt_lgb_positive_amount"] = lgb_positive
                hurdle_preds = {}
                for split, X in X_by_split.items():
                    positive_amount = _clip_prediction(_predict_lgb(lgb_positive, X), y_by_split[split])
                    hurdle_preds[split] = _clip_prediction(binary_preds[split] * positive_amount, y_by_split[split])
                predictions["alt_lgb_hurdle"] = hurdle_preds
                calibration_factors["alt_lgb_hurdle"] = 1.0
                hurdle_cal_preds, hurdle_k = _mean_calibrate(hurdle_preds, y_val)
                predictions["alt_lgb_hurdle_valcal"] = hurdle_cal_preds
                calibration_factors["alt_lgb_hurdle_valcal"] = hurdle_k
                notes.append("Target is non-binary, so hurdle = P(target > 0) * E(target | target > 0).")
            else:
                notes.append("Hurdle amount regressor skipped: too few positive observations in train or validation.")

    results_df = _metrics_rows(predictions, y_by_split, calibration_factors=calibration_factors)

    report_path = artifacts_dir / "alternative_modeling_report.xlsx"
    if save_artifacts:
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        lgb_binary.save_model(str(artifacts_dir / "alt_lgb_binary_prob.txt"))
        if "alt_lgb_positive_amount" in models:
            models["alt_lgb_positive_amount"].save_model(str(artifacts_dir / "alt_lgb_positive_amount.txt"))
        _save_report(report_path, results_df, notes)

    return {
        "models": models,
        "predictions": predictions,
        "results_df": results_df,
        "calibration_factors": calibration_factors,
        "notes": notes,
        "report_path": report_path if save_artifacts else None,
        "feature_cols": feature_cols,
        "target_col": target_col,
        "prediction_col": prediction_col,
        "is_binary_target": is_binary_target,
    }
