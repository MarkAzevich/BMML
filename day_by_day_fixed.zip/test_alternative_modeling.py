import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from alternative_modeling import build_alternative_models


def _binary_problem(seed=42):
    rng = np.random.default_rng(seed)

    def make_part(n, shift=0.0):
        cat = rng.integers(0, 4, size=n, dtype=np.int32)
        x1 = rng.normal(shift, 1.0, size=n).astype("float32")
        x2 = rng.normal(0.0, 1.0, size=n).astype("float32")
        logits = -2.2 + 0.9 * x1 + 0.5 * (cat == 2) - 0.3 * x2
        p = 1.0 / (1.0 + np.exp(-logits))
        y = rng.binomial(1, p).astype("float32")
        X = pd.DataFrame({"cat": cat, "x1": x1, "x2": x2})
        return X, y

    return make_part(600, 0.0), make_part(220, 0.05), make_part(200, 0.1), make_part(180, 0.2)


class AlternativeModelingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            import lightgbm  # noqa: F401
        except ImportError as exc:
            raise unittest.SkipTest("LightGBM is not installed") from exc

    def test_binary_alternative_models_run_and_write_report(self):
        (X_train, y_train), (X_val, y_val), (X_test, y_test), (X_oot, y_oot) = _binary_problem()
        with tempfile.TemporaryDirectory() as tmp:
            result = build_alternative_models(
                X_train=X_train,
                y_train=y_train,
                X_val=X_val,
                y_val=y_val,
                X_test=X_test,
                y_test=y_test,
                X_oot=X_oot,
                y_oot=y_oot,
                categorical_feature=[0],
                feature_cols=list(X_train.columns),
                target_col="total_sls_qty",
                prediction_col="prediction",
                artifacts_dir=Path(tmp),
                seed=7,
                max_boost_rounds=40,
                early_stopping_rounds=5,
            )
            self.assertTrue(Path(result["report_path"]).exists())

        self.assertTrue(result["is_binary_target"])
        self.assertIn("alt_lgb_binary_prob", result["predictions"])
        self.assertIn("alt_lgb_binary_prob_valcal", result["predictions"])
        self.assertIn("alt_lgb_hurdle", result["predictions"])
        self.assertGreater(len(result["results_df"]), 0)

        oot_pred = result["predictions"]["alt_lgb_binary_prob"]["oot"]
        self.assertEqual(len(oot_pred), len(y_oot))
        self.assertTrue(np.all(np.isfinite(oot_pred)))
        self.assertTrue(np.all((oot_pred >= 0) & (oot_pred <= 1)))
        self.assertEqual(result["target_col"], "total_sls_qty")


if __name__ == "__main__":
    unittest.main()
