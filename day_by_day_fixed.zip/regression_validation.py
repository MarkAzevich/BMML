from __future__ import annotations

import datetime as _dt
import math
import pickle
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy import stats


TRAFFIC_ORDER = {"green": 0, "yellow": 1, "red": 2, "gray": -1}
TRAFFIC_RU = {
    "green": "Зеленый",
    "yellow": "Желтый",
    "red": "Красный",
    "gray": "Не применимо",
}
TRAFFIC_HEX = {
    "green": "70AD47",
    "yellow": "FFC000",
    "red": "C00000",
    "gray": "BFBFBF",
}


@dataclass
class RegressionValidationConfig:
    """Config for Part 46 regression validation traffic-light tests.

    primary_metric supports:
    - "mae"
    - "rmse"
    - "mae_to_mean" / "mae_to_min" aliases

    categorical_cols is optional. Object/category columns are handled
    automatically; pass explicit names for numeric categorical codes.

    All three are lower-is-better metrics. For raw MAE/RMSE, absolute
    stability thresholds are business parameters and should be set consciously.
    """

    target_col: str = "target"
    prediction_col: str = "prediction"
    categorical_cols: Optional[List[str]] = None
    primary_metric: str = "mae"
    oos_name: str = "test"
    oot_name: str = "oot"
    random_state: int = 42
    eps: float = 1e-12

    # Optional performance caps. None means the test uses the full split.
    # Keep caps unset for methodology-faithful validation runs.

    # Test 1.1
    split_cv_splits: int = 4
    split_n_random: int = 200
    split_sample_size: Optional[int] = None
    split_green_quantile_max: float = 0.95
    split_yellow_quantile_max: float = 0.99

    # Test 1.2
    psi_min_bucket_share: float = 0.05
    psi_max_bins: int = 20
    psi_sample_size: Optional[int] = None
    feature_psi_yellow_min: float = 0.20
    feature_psi_yellow_share_max: float = 0.20

    # Test 2.1
    baseline_tolerance: float = 1e-12
    max_single_feature_baselines: Optional[int] = None

    # Test 2.2, informative but also used as a note for 1.1.
    bootstrap_n: int = 300
    bootstrap_sample_size: Optional[int] = None
    ci_alpha: float = 0.05

    # Test 3.1
    spearman_green_min: float = 0.30
    spearman_yellow_min: float = 0.20

    # Test 3.2 / 5.3
    mean_rel_diff_oos_green_abs_max: float = 0.15
    mean_rel_diff_oos_yellow_abs_max: float = 0.30
    mean_rel_diff_oot_green_abs_max: float = 0.25
    mean_rel_diff_oot_yellow_abs_max: float = 0.50

    # Test 4.3
    ftest_green_pvalue_max: float = 0.01
    ftest_yellow_pvalue_max: float = 0.05

    # Test 4.4
    vif_yellow_min: float = 3.0
    vif_red_min: float = 5.0
    vif_bad_share_red_min: float = 0.20
    vif_bad_share_yellow_min: float = 0.20
    vif_sample_size: Optional[int] = None
    vif_max_features: Optional[int] = None

    # Test 5.1 / 5.2, deterioration for lower-is-better metric.
    stability_abs_yellow_min: float = 0.15
    stability_rel_yellow_min: float = 0.20
    stability_abs_red_min: float = 0.25
    stability_rel_red_min: float = 0.30


@dataclass
class RegressionValidationResult:
    model_name: str
    overall_light: str
    block_summary: pd.DataFrame
    test_summary: pd.DataFrame
    details: Dict[str, pd.DataFrame]
    output_path: Optional[Path]
    config: RegressionValidationConfig


def load_frame(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in {".parquet", ".pq"}:
        return pd.read_parquet(path)
    if suffix in {".pkl", ".pickle"}:
        obj = pd.read_pickle(path)
        if not isinstance(obj, pd.DataFrame):
            raise TypeError(f"{path} contains {type(obj).__name__}, expected DataFrame")
        return obj
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix == ".tsv":
        return pd.read_csv(path, sep="\t")
    raise ValueError(f"Unsupported frame format: {path.suffix}")


def load_model(path: str | Path) -> Any:
    path = Path(path)
    if path.suffix.lower() == ".joblib":
        try:
            import joblib

            return joblib.load(path)
        except ImportError as exc:
            raise ImportError("joblib is required to load .joblib models") from exc
    with open(path, "rb") as f:
        return pickle.load(f)


def make_validation_frame(
    X: pd.DataFrame | np.ndarray,
    y: Iterable[float],
    pred: Optional[Iterable[float]] = None,
    *,
    target_col: str = "target",
    prediction_col: str = "prediction",
) -> pd.DataFrame:
    if isinstance(X, pd.DataFrame):
        out = X.copy()
    else:
        out = pd.DataFrame(X)
    out[target_col] = np.asarray(y, dtype="float64")
    if pred is not None:
        out[prediction_col] = np.asarray(pred, dtype="float64")
    return out


def validate_regression_model_from_files(
    *,
    train_path: str | Path,
    oos_path: str | Path,
    oot_path: Optional[str | Path] = None,
    model_name: str = "model",
    model_path: Optional[str | Path] = None,
    model: Any = None,
    predict_fn: Optional[Callable[[pd.DataFrame], Iterable[float]]] = None,
    feature_cols: Optional[List[str]] = None,
    categorical_cols: Optional[List[str]] = None,
    target_col: Optional[str] = None,
    prediction_col: Optional[str] = None,
    output_path: Optional[str | Path] = None,
    config: Optional[RegressionValidationConfig] = None,
) -> RegressionValidationResult:
    train_df = load_frame(train_path)
    oos_df = load_frame(oos_path)
    oot_df = load_frame(oot_path) if oot_path is not None else None
    if model is None and model_path is not None:
        model = load_model(model_path)
    if config is None:
        config = RegressionValidationConfig(
            target_col=target_col or "target",
            prediction_col=prediction_col or "prediction",
        )
    return validate_regression_model(
        train_df=train_df,
        oos_df=oos_df,
        oot_df=oot_df,
        model_name=model_name,
        model=model,
        predict_fn=predict_fn,
        feature_cols=feature_cols,
        categorical_cols=categorical_cols,
        target_col=target_col,
        prediction_col=prediction_col,
        output_path=output_path,
        config=config,
    )


def validate_regression_model(
    *,
    train_df: pd.DataFrame,
    oos_df: pd.DataFrame,
    oot_df: Optional[pd.DataFrame] = None,
    model_name: str = "model",
    model: Any = None,
    predict_fn: Optional[Callable[[pd.DataFrame], Iterable[float]]] = None,
    feature_cols: Optional[List[str]] = None,
    categorical_cols: Optional[List[str]] = None,
    target_col: Optional[str] = None,
    prediction_col: Optional[str] = None,
    train_pred: Optional[Iterable[float]] = None,
    oos_pred: Optional[Iterable[float]] = None,
    oot_pred: Optional[Iterable[float]] = None,
    output_path: Optional[str | Path] = None,
    config: Optional[RegressionValidationConfig] = None,
) -> RegressionValidationResult:
    if config is None:
        config = RegressionValidationConfig(
            target_col=target_col or "target",
            prediction_col=prediction_col or "prediction",
        )
    else:
        config = replace(
            config,
            target_col=target_col if target_col is not None else config.target_col,
            prediction_col=prediction_col if prediction_col is not None else config.prediction_col,
        )
    if categorical_cols is not None:
        config = replace(config, categorical_cols=list(categorical_cols))
    if config.categorical_cols is not None:
        config = replace(config, categorical_cols=[str(c) for c in config.categorical_cols])
    config = replace(config, primary_metric=normalize_metric_name(config.primary_metric))

    feature_cols = _resolve_feature_cols(
        train_df=train_df,
        oos_df=oos_df,
        oot_df=oot_df,
        feature_cols=feature_cols,
        target_col=config.target_col,
        prediction_col=config.prediction_col,
        model=model,
    )
    categorical_set = _categorical_cols_set(config, feature_cols)

    y_train = _target(train_df, config.target_col, "train")
    y_oos = _target(oos_df, config.target_col, config.oos_name)
    y_oot = _target(oot_df, config.target_col, config.oot_name) if oot_df is not None else None

    pred_train = _resolve_predictions(
        train_df,
        feature_cols=feature_cols,
        categorical_cols=categorical_set,
        prediction_col=config.prediction_col,
        explicit_pred=train_pred,
        model=model,
        predict_fn=predict_fn,
        required=True,
    )
    pred_oos = _resolve_predictions(
        oos_df,
        feature_cols=feature_cols,
        categorical_cols=categorical_set,
        prediction_col=config.prediction_col,
        explicit_pred=oos_pred,
        model=model,
        predict_fn=predict_fn,
        required=True,
    )
    pred_oot = (
        _resolve_predictions(
            oot_df,
            feature_cols=feature_cols,
            categorical_cols=categorical_set,
            prediction_col=config.prediction_col,
            explicit_pred=oot_pred,
            model=model,
            predict_fn=predict_fn,
            required=True,
        )
        if oot_df is not None
        else None
    )

    metrics_df = _metrics_table(
        y_train=y_train,
        pred_train=pred_train,
        y_oos=y_oos,
        pred_oos=pred_oos,
        y_oot=y_oot,
        pred_oot=pred_oot,
        config=config,
    )

    details: Dict[str, pd.DataFrame] = {
        "metrics_by_split": metrics_df,
        "model_features": pd.DataFrame(
            {
                "feature": feature_cols,
                "is_categorical": [c in categorical_set for c in feature_cols],
            }
        ),
    }
    tests: List[Dict[str, Any]] = []

    t22, d22 = _test_metric_ci(
        y_train, pred_train, y_oos, pred_oos, y_oot, pred_oot, config
    )
    tests.append(t22)
    details["T2_2_metric_ci"] = d22
    ci_train_oos_overlap = _ci_overlap(d22, "train", config.oos_name)

    t11, d11 = _test_split_quality(
        train_df, oos_df, feature_cols, config, ci_train_oos_overlap
    )
    tests.append(t11)
    details["T1_1_split_quality"] = d11

    t12, d12 = _test_feature_psi(train_df, oos_df, oot_df, feature_cols, config)
    tests.append(t12)
    details["T1_2_feature_psi"] = d12

    t21, d21 = _test_baselines(train_df, oos_df, feature_cols, pred_oos, y_train, y_oos, config)
    tests.append(t21)
    details["T2_1_baselines"] = d21

    t31, d31 = _test_spearman(y_oos, pred_oos, config)
    tests.append(t31)
    details["T3_1_spearman_oos"] = d31

    t32, d32 = _test_mean_equality(
        y_oos,
        pred_oos,
        split_name=config.oos_name,
        test_id="3.2",
        block="Калибровка модели",
        test_name="Равенство среднего прогнозного и фактического значения на OOS",
        green_abs=config.mean_rel_diff_oos_green_abs_max,
        yellow_abs=config.mean_rel_diff_oos_yellow_abs_max,
        config=config,
    )
    tests.append(t32)
    details["T3_2_mean_oos"] = d32

    t43, d43 = _test_regression_ftest(oos_df, feature_cols, y_oos, config)
    tests.append(t43)
    details["T4_3_regression_ftest"] = d43

    t44, d44 = _test_vif(train_df, feature_cols, config)
    tests.append(t44)
    details["T4_4_vif"] = d44

    t51, d51 = _test_metric_stability(metrics_df, "5.1", "OOS -> OOT", config.oos_name, config.oot_name, config)
    tests.append(t51)
    details["T5_1_stability_oos_oot"] = d51

    t52, d52 = _test_metric_stability(metrics_df, "5.2", "train -> OOS", "train", config.oos_name, config)
    tests.append(t52)
    details["T5_2_stability_train_oos"] = d52

    if y_oot is not None and pred_oot is not None:
        t53, d53 = _test_mean_equality(
            y_oot,
            pred_oot,
            split_name=config.oot_name,
            test_id="5.3",
            block="Стабильность модели",
            test_name="Равенство среднего прогнозного и фактического значения на OOT",
            green_abs=config.mean_rel_diff_oot_green_abs_max,
            yellow_abs=config.mean_rel_diff_oot_yellow_abs_max,
            config=config,
        )
    else:
        t53 = _summary_row(
            "5.3",
            "Стабильность модели",
            "Равенство среднего прогнозного и фактического значения на OOT",
            "yellow",
            np.nan,
            "OOT required",
            "OOT отсутствует: по методике это зона риска для блока стабильности.",
            informative=False,
        )
        d53 = pd.DataFrame()
    tests.append(t53)
    details["T5_3_mean_oot"] = d53

    test_summary = pd.DataFrame(tests)
    block_summary = _block_summary(test_summary)
    overall_light = _worst_light(block_summary["traffic_light_code"].tolist())

    details["methodology_map"] = _methodology_map(config)
    details["config"] = pd.DataFrame(
        [{"parameter": k, "value": v} for k, v in asdict(config).items()]
    )

    out_path = Path(output_path) if output_path is not None else None
    if out_path is not None:
        _write_excel_report(
            output_path=out_path,
            model_name=model_name,
            overall_light=overall_light,
            block_summary=block_summary,
            test_summary=test_summary,
            details=details,
            config=config,
        )

    return RegressionValidationResult(
        model_name=model_name,
        overall_light=overall_light,
        block_summary=block_summary,
        test_summary=test_summary,
        details=details,
        output_path=out_path,
        config=config,
    )


def normalize_metric_name(metric: str) -> str:
    key = str(metric).strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "mae": "mae",
        "rmse": "rmse",
        "mae_to_mean": "mae_to_mean",
        "mae_to_mean_fact": "mae_to_mean",
        "mae_mean": "mae_to_mean",
        "mae_to_min": "mae_to_mean",
        "mae/min": "mae_to_mean",
        "mae/mean": "mae_to_mean",
    }
    if key not in aliases:
        raise ValueError(
            f"Unsupported primary_metric={metric!r}; choose mae, rmse, mae_to_mean"
        )
    return aliases[key]


def metric_display_name(metric: str) -> str:
    metric = normalize_metric_name(metric)
    return {"mae": "MAE", "rmse": "RMSE", "mae_to_mean": "MAE-to-Mean"}[metric]


def metric_value(y: np.ndarray, pred: np.ndarray, metric: str, eps: float = 1e-12) -> float:
    metric = normalize_metric_name(metric)
    err = y - pred
    if metric == "mae":
        return float(np.mean(np.abs(err)))
    if metric == "rmse":
        return float(np.sqrt(np.mean(err**2)))
    mean_y = float(np.mean(y))
    return float(np.mean(np.abs(err)) / abs(mean_y)) if abs(mean_y) > eps else np.nan


def infer_model_feature_names(model: Any) -> List[str]:
    if model is None:
        return []
    candidates = []
    for attr in ("feature_names_", "feature_name_", "feature_names_in_"):
        value = getattr(model, attr, None)
        if value is not None:
            candidates.append(value)
    if hasattr(model, "feature_name"):
        try:
            candidates.append(model.feature_name())
        except Exception:
            pass
    if hasattr(model, "get_booster"):
        try:
            booster = model.get_booster()
            if getattr(booster, "feature_names", None):
                candidates.append(booster.feature_names)
        except Exception:
            pass
    if getattr(model, "feature_names", None):
        candidates.append(model.feature_names)
    for item in candidates:
        if item is None:
            continue
        names = list(item)
        if names:
            return [str(x) for x in names]
    return []


def predict_with_model(
    model: Any, X: pd.DataFrame, categorical_cols: Optional[Iterable[str]] = None
) -> np.ndarray:
    """Model-safe predict for sklearn-like, CatBoost, LightGBM and XGBoost."""

    if model is None:
        raise ValueError("model is None")

    module = type(model).__module__.lower()
    cls = type(model).__name__.lower()
    categorical_set = set(categorical_cols or [])
    X_model = _prepare_model_frame_for_library(X, module, categorical_set)

    if "xgboost" in module and cls == "booster":
        return _predict_xgb_booster(model, X_model, categorical_set)

    if "lightgbm" in module and cls == "booster":
        best_iter = getattr(model, "best_iteration", None)
        kwargs = {"num_iteration": int(best_iter)} if best_iter else {}
        return _as_1d_float(
            model.predict(X_model, **kwargs),
            "lightgbm.Booster.predict",
        )

    if hasattr(model, "predict"):
        try:
            return _as_1d_float(model.predict(X_model), f"{type(model).__name__}.predict")
        except Exception as first_exc:
            if "xgboost" in module:
                import xgboost as xgb

                X_use = _prepare_xgb_frame(X_model, categorical_set)
                try:
                    return _as_1d_float(
                        model.predict(xgb.DMatrix(X_use, enable_categorical=True)),
                        f"{type(model).__name__}.predict(DMatrix)",
                    )
                except Exception:
                    raise first_exc
            if "catboost" in module and categorical_set:
                try:
                    from catboost import Pool

                    cat_features = [c for c in X.columns if c in categorical_set]
                    return _as_1d_float(
                        model.predict(Pool(X, cat_features=cat_features)),
                        f"{type(model).__name__}.predict(Pool)",
                    )
                except Exception:
                    raise first_exc
            raise
    raise TypeError(f"Model {type(model).__name__} has no predict() method")


def _predict_xgb_booster(
    model: Any, X: pd.DataFrame, categorical_set: set[str]
) -> np.ndarray:
    import xgboost as xgb

    X_use = _prepare_xgb_frame(X, categorical_set)
    dmatrix = xgb.DMatrix(X_use, enable_categorical=True)
    best_iteration = None
    try:
        attr = model.attr("best_iteration")
        best_iteration = int(attr) if attr is not None else None
    except Exception:
        best_iteration = None

    if best_iteration is not None:
        try:
            pred = model.predict(dmatrix, iteration_range=(0, best_iteration + 1))
            return _as_1d_float(pred, "xgboost.Booster.predict(best_iteration)")
        except TypeError:
            best_ntree_limit = getattr(model, "best_ntree_limit", None)
            if best_ntree_limit:
                pred = model.predict(dmatrix, ntree_limit=best_ntree_limit)
                return _as_1d_float(pred, "xgboost.Booster.predict(best_ntree_limit)")

    return _as_1d_float(
        model.predict(dmatrix),
        "xgboost.Booster.predict",
    )


def _prepare_model_frame_for_library(
    X: pd.DataFrame, module: str, categorical_cols: Iterable[str]
) -> pd.DataFrame:
    if "xgboost" in module or "lightgbm" in module:
        out = X.copy()
        categorical_set = set(categorical_cols)
        for c in out.columns:
            if c in categorical_set or pd.api.types.is_object_dtype(out[c]):
                out[c] = out[c].astype("category")
        return out
    return X


def _prepare_xgb_frame(
    X: pd.DataFrame, categorical_cols: Optional[Iterable[str]] = None
) -> pd.DataFrame:
    out = X.copy()
    categorical_set = set(categorical_cols or [])
    for c in out.columns:
        if c in categorical_set or pd.api.types.is_object_dtype(out[c]):
            out[c] = out[c].astype("category")
    return out


def _categorical_cols_set(
    config: RegressionValidationConfig, feature_cols: Sequence[str]
) -> set[str]:
    explicit = set(config.categorical_cols or [])
    unknown = sorted(explicit.difference(feature_cols))
    if unknown:
        raise ValueError(f"categorical_cols are not present in feature_cols: {unknown}")
    return explicit


def _resolve_feature_cols(
    *,
    train_df: pd.DataFrame,
    oos_df: pd.DataFrame,
    oot_df: Optional[pd.DataFrame],
    feature_cols: Optional[List[str]],
    target_col: str,
    prediction_col: str,
    model: Any,
) -> List[str]:
    if feature_cols is None:
        inferred = infer_model_feature_names(model)
        if inferred and all(c in train_df.columns for c in inferred):
            cols = inferred
        else:
            excluded = {target_col, prediction_col}
            cols = [c for c in train_df.columns if c not in excluded]
    else:
        cols = list(feature_cols)

    frames = [("train", train_df), ("oos", oos_df)]
    if oot_df is not None:
        frames.append(("oot", oot_df))
    missing = {name: [c for c in cols if c not in df.columns] for name, df in frames}
    missing = {k: v for k, v in missing.items() if v}
    if missing:
        raise ValueError(f"Feature columns are missing in validation frames: {missing}")
    return cols


def _target(df: Optional[pd.DataFrame], target_col: str, split_name: str) -> np.ndarray:
    if df is None:
        raise ValueError(f"{split_name} DataFrame is None")
    if target_col not in df.columns:
        raise ValueError(f"{split_name}: target column {target_col!r} not found")
    return _as_1d_float(df[target_col].values, f"{split_name}.{target_col}")


def _resolve_predictions(
    df: Optional[pd.DataFrame],
    *,
    feature_cols: List[str],
    categorical_cols: Iterable[str],
    prediction_col: str,
    explicit_pred: Optional[Iterable[float]],
    model: Any,
    predict_fn: Optional[Callable[[pd.DataFrame], Iterable[float]]],
    required: bool,
) -> Optional[np.ndarray]:
    if df is None:
        return None
    if explicit_pred is not None:
        pred = explicit_pred
    elif prediction_col in df.columns:
        pred = df[prediction_col].values
    elif predict_fn is not None:
        pred = predict_fn(df[feature_cols])
    elif model is not None:
        pred = predict_with_model(model, df[feature_cols], categorical_cols=categorical_cols)
    elif required:
        raise ValueError(
            f"Predictions are required: pass {prediction_col!r}, explicit *_pred, "
            "model with predict(), or predict_fn."
        )
    else:
        return None

    pred_arr = _as_1d_float(pred, "prediction")
    if len(pred_arr) != len(df):
        raise ValueError(f"Prediction length {len(pred_arr)} != frame length {len(df)}")
    return pred_arr


def _as_1d_float(values: Iterable[float], name: str) -> np.ndarray:
    arr = np.asarray(values, dtype="float64")
    if arr.ndim == 2 and 1 in arr.shape:
        arr = arr.reshape(-1)
    if arr.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional, got shape {arr.shape}")
    if not np.isfinite(arr).all():
        bad = int((~np.isfinite(arr)).sum())
        raise ValueError(f"{name} contains {bad} non-finite values")
    return arr


def _metrics(y: np.ndarray, pred: np.ndarray, split: str, config: RegressionValidationConfig) -> Dict[str, Any]:
    err = y - pred
    mae = float(np.mean(np.abs(err)))
    rmse = float(np.sqrt(np.mean(err**2)))
    mean_fact = float(np.mean(y))
    mean_pred = float(np.mean(pred))
    rel_mean_diff = (
        (mean_pred - mean_fact) / abs(mean_fact)
        if abs(mean_fact) > config.eps
        else np.nan
    )
    return {
        "split": split,
        "n": len(y),
        "MAE": mae,
        "RMSE": rmse,
        "MAE_to_Mean": mae / abs(mean_fact) if abs(mean_fact) > config.eps else np.nan,
        "primary_metric": metric_display_name(config.primary_metric),
        "primary_metric_value": metric_value(y, pred, config.primary_metric, config.eps),
        "mean_fact": mean_fact,
        "mean_pred": mean_pred,
        "fact_pred_ratio": mean_fact / mean_pred if abs(mean_pred) > config.eps else np.nan,
        "signed_rel_mean_diff": rel_mean_diff,
        "abs_rel_mean_diff": abs(rel_mean_diff) if not pd.isna(rel_mean_diff) else np.nan,
    }


def _metrics_table(
    *,
    y_train: np.ndarray,
    pred_train: np.ndarray,
    y_oos: np.ndarray,
    pred_oos: np.ndarray,
    y_oot: Optional[np.ndarray],
    pred_oot: Optional[np.ndarray],
    config: RegressionValidationConfig,
) -> pd.DataFrame:
    rows = [
        _metrics(y_train, pred_train, "train", config),
        _metrics(y_oos, pred_oos, config.oos_name, config),
    ]
    if y_oot is not None and pred_oot is not None:
        rows.append(_metrics(y_oot, pred_oot, config.oot_name, config))
    return pd.DataFrame(rows)


def _summary_row(
    test_id: str,
    block: str,
    test_name: str,
    light: str,
    metric_value: Any,
    threshold: str,
    comment: str,
    *,
    informative: bool = False,
) -> Dict[str, Any]:
    return {
        "test_id": test_id,
        "block": block,
        "test_name": test_name,
        "traffic_light_code": light,
        "traffic_light": TRAFFIC_RU[light],
        "metric_value": metric_value,
        "threshold": threshold,
        "informative": informative,
        "comment": comment,
    }


def _worst_light(lights: Iterable[str]) -> str:
    real = [x for x in lights if x in {"green", "yellow", "red"}]
    if not real:
        return "gray"
    return max(real, key=lambda x: TRAFFIC_ORDER[x])


def _test_metric_ci(
    y_train: np.ndarray,
    pred_train: np.ndarray,
    y_oos: np.ndarray,
    pred_oos: np.ndarray,
    y_oot: Optional[np.ndarray],
    pred_oot: Optional[np.ndarray],
    config: RegressionValidationConfig,
) -> Tuple[Dict[str, Any], pd.DataFrame]:
    rows = []
    for split, y, pred in [
        ("train", y_train, pred_train),
        (config.oos_name, y_oos, pred_oos),
        (config.oot_name, y_oot, pred_oot),
    ]:
        if y is None or pred is None:
            continue
        rows.append(_bootstrap_metric_ci(split, y, pred, config))
    detail = pd.DataFrame(rows)
    oos_row = detail[detail["split"].eq(config.oos_name)].iloc[0]
    return (
        _summary_row(
            "2.2",
            "Качество работы модели / точность",
            "Доверительный интервал ключевой метрики качества",
            "gray",
            float(oos_row["metric_value"]),
            "Информативный тест, светофор не выставляется",
            "Bootstrap CI по фиксированным предсказаниям; модель не переобучается.",
            informative=True,
        ),
        detail,
    )


def _bootstrap_metric_ci(
    split: str, y: np.ndarray, pred: np.ndarray, config: RegressionValidationConfig
) -> Dict[str, Any]:
    rng = np.random.default_rng(config.random_state + _stable_seed_offset(split))
    n = len(y)
    sample_n = min(n, config.bootstrap_sample_size) if config.bootstrap_sample_size else n
    values = []
    for _ in range(config.bootstrap_n):
        idx = rng.choice(n, size=sample_n, replace=True)
        values.append(metric_value(y[idx], pred[idx], config.primary_metric, config.eps))
    finite_values = np.asarray(values, dtype="float64")
    finite_values = finite_values[np.isfinite(finite_values)]
    alpha = config.ci_alpha
    if len(finite_values):
        ci_low = float(np.quantile(finite_values, alpha / 2))
        ci_high = float(np.quantile(finite_values, 1 - alpha / 2))
    else:
        ci_low = np.nan
        ci_high = np.nan
    return {
        "split": split,
        "metric": metric_display_name(config.primary_metric),
        "metric_value": metric_value(y, pred, config.primary_metric, config.eps),
        "ci_low": ci_low,
        "ci_high": ci_high,
        "bootstrap_n": config.bootstrap_n,
        "sample_size": sample_n,
        "n": n,
    }


def _stable_seed_offset(value: str) -> int:
    total = 0
    for i, ch in enumerate(str(value), start=1):
        total += i * ord(ch)
    return total % 10_000


def _ci_overlap(ci_df: pd.DataFrame, split_a: str, split_b: str) -> bool:
    a = ci_df[ci_df["split"].eq(split_a)]
    b = ci_df[ci_df["split"].eq(split_b)]
    if a.empty or b.empty:
        return True
    a0, a1 = float(a.iloc[0]["ci_low"]), float(a.iloc[0]["ci_high"])
    b0, b1 = float(b.iloc[0]["ci_low"]), float(b.iloc[0]["ci_high"])
    return max(a0, b0) <= min(a1, b1)


def _test_split_quality(
    train_df: pd.DataFrame,
    oos_df: pd.DataFrame,
    feature_cols: List[str],
    config: RegressionValidationConfig,
    ci_train_oos_overlap: bool,
) -> Tuple[Dict[str, Any], pd.DataFrame]:
    try:
        from sklearn.linear_model import LogisticRegression
        from sklearn.metrics import roc_auc_score
        from sklearn.model_selection import StratifiedKFold
    except ImportError:
        detail = pd.DataFrame()
        return (
            _summary_row(
                "1.1",
                "Качество данных",
                "Качество разбиения train/OOS",
                "gray",
                np.nan,
                "sklearn required",
                "sklearn недоступен, тест не выполнен.",
            ),
            detail,
        )

    train_s, oos_s = _sample_two_frames(
        train_df, oos_df, config.split_sample_size, config.random_state
    )
    X_raw = pd.concat([train_s[feature_cols], oos_s[feature_cols]], ignore_index=True)
    y = np.r_[np.zeros(len(train_s), dtype=int), np.ones(len(oos_s), dtype=int)]
    min_class_count = int(min(np.bincount(y)))
    n_splits = min(config.split_cv_splits, min_class_count)
    if n_splits < 2 or not feature_cols:
        detail = pd.DataFrame()
        return (
            _summary_row(
                "1.1",
                "Качество данных",
                "Качество разбиения train/OOS",
                "gray",
                np.nan,
                "Need >=2 rows per class and >=1 feature",
                "Недостаточно данных для CV-теста разбиения.",
            ),
            detail,
        )

    X = _encode_for_sklearn(X_raw, categorical_cols=config.categorical_cols)
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=config.random_state)

    def cv_gini(labels: np.ndarray) -> float:
        scores = []
        for tr_idx, va_idx in cv.split(X, labels):
            clf = LogisticRegression(
                max_iter=500,
                solver="lbfgs",
                class_weight="balanced",
                random_state=config.random_state,
            )
            clf.fit(X.iloc[tr_idx], labels[tr_idx])
            proba = clf.predict_proba(X.iloc[va_idx])[:, 1]
            scores.append(2 * roc_auc_score(labels[va_idx], proba) - 1)
        return float(np.mean(scores))

    rng = np.random.default_rng(config.random_state)
    actual_gini = cv_gini(y)
    random_ginis = [cv_gini(rng.permutation(y)) for _ in range(config.split_n_random)]
    random_arr = np.asarray(random_ginis)
    q = float(np.mean(random_arr <= actual_gini))

    if q > config.split_yellow_quantile_max and not ci_train_oos_overlap:
        light = "red"
    elif q > config.split_green_quantile_max:
        light = "yellow"
    else:
        light = "green"

    detail = pd.DataFrame(
        [
            {
                "actual_gini": actual_gini,
                "random_gini_mean": float(np.mean(random_arr)),
                "random_gini_p95": float(np.quantile(random_arr, 0.95)),
                "random_gini_p99": float(np.quantile(random_arr, 0.99)),
                "actual_quantile_q": q,
                "ci_train_oos_overlap": ci_train_oos_overlap,
                "n_train": len(train_s),
                "n_oos": len(oos_s),
                "n_features": len(feature_cols),
                "n_random": config.split_n_random,
            }
        ]
    )
    threshold = "red: q>0.99 and train/OOS metric CI do not overlap; yellow: q>0.95; green: q<=0.95"
    return (
        _summary_row(
            "1.1",
            "Качество данных",
            "Качество разбиения train/OOS",
            light,
            q,
            threshold,
            "Gini модели, предсказывающей исходный split, сравнен со случайными split-label shuffles.",
        ),
        detail,
    )


def _test_feature_psi(
    train_df: pd.DataFrame,
    oos_df: pd.DataFrame,
    oot_df: Optional[pd.DataFrame],
    feature_cols: List[str],
    config: RegressionValidationConfig,
) -> Tuple[Dict[str, Any], pd.DataFrame]:
    rows = []
    train_s = _sample_frame(train_df, config.psi_sample_size, config.random_state)
    comparisons = [(config.oos_name, oos_df)]
    if oot_df is not None:
        comparisons.append((config.oot_name, oot_df))
    for split_name, cmp_df in comparisons:
        cmp_s = _sample_frame(cmp_df, config.psi_sample_size, config.random_state + 1)
        for feature in feature_cols:
            rows.append(
                _psi_for_feature(
                    train_s[feature],
                    cmp_s[feature],
                    feature,
                    split_name,
                    config,
                    force_discrete=feature in set(config.categorical_cols or []),
                )
            )
    detail = pd.DataFrame(rows)
    if detail.empty:
        return (
            _summary_row(
                "1.2",
                "Качество данных",
                "Однородность OOS/OOT относительно train по PSI факторов",
                "gray",
                np.nan,
                "Need feature columns",
                "Нет факторов для PSI.",
            ),
            detail,
        )
    by_split = (
        detail.assign(is_yellow=detail["traffic_light_code"].eq("yellow"))
        .groupby("compare_split")
        .agg(
            features=("feature", "count"),
            yellow_features=("is_yellow", "sum"),
            yellow_share=("is_yellow", "mean"),
            max_psi=("PSI", "max"),
        )
        .reset_index()
    )
    worst_share = float(by_split["yellow_share"].max())
    light = "yellow" if worst_share > config.feature_psi_yellow_share_max else "green"
    detail = pd.concat(
        [detail, pd.DataFrame([{}]), by_split.assign(feature="__SUMMARY__")],
        ignore_index=True,
        sort=False,
    )
    threshold = "feature yellow: PSI>=0.2; test yellow: more than 20% yellow features"
    return (
        _summary_row(
            "1.2",
            "Качество данных",
            "Однородность OOS/OOT относительно train по PSI факторов",
            light,
            worst_share,
            threshold,
            "PSI считается по исходным переданным факторам; missing входит отдельным бакетом.",
        ),
        detail,
    )


def _test_baselines(
    train_df: pd.DataFrame,
    oos_df: pd.DataFrame,
    feature_cols: List[str],
    pred_oos: np.ndarray,
    y_train: np.ndarray,
    y_oos: np.ndarray,
    config: RegressionValidationConfig,
) -> Tuple[Dict[str, Any], pd.DataFrame]:
    rows = []
    model_metric = metric_value(y_oos, pred_oos, config.primary_metric, config.eps)

    constants = {
        "constant_mean_train": float(np.mean(y_train)),
        "constant_median_train": float(np.median(y_train)),
        "constant_mode_train": _mode_float(y_train),
        "constant_zero": 0.0,
    }
    for name, value in constants.items():
        train_base = np.full_like(y_train, value, dtype="float64")
        oos_base = np.full_like(y_oos, value, dtype="float64")
        rows.append(_baseline_row(name, oos_base, y_oos, config, "base_prediction"))
        rows.append(
            _ols_on_baseline_row(
                f"ols_on:{name}",
                train_base,
                oos_base,
                y_train,
                y_oos,
                config,
            )
        )

    categorical_set = set(config.categorical_cols or [])
    numeric_cols = [
        c
        for c in feature_cols
        if c not in categorical_set and pd.api.types.is_numeric_dtype(train_df[c])
    ]
    if config.max_single_feature_baselines is not None:
        numeric_cols = numeric_cols[: config.max_single_feature_baselines]
    for col in numeric_cols:
        tr_x = pd.to_numeric(train_df[col], errors="coerce").astype("float64")
        os_x = pd.to_numeric(oos_df[col], errors="coerce").astype("float64")
        if tr_x.isna().all() or os_x.isna().all():
            continue
        fill = float(tr_x.median())
        train_base = tr_x.fillna(fill).values
        oos_base = os_x.fillna(fill).values
        rows.append(
            _baseline_row(
                f"feature_as_prediction:{col}",
                oos_base,
                y_oos,
                config,
                "base_prediction",
            )
        )
        rows.append(
            _ols_on_baseline_row(
                f"ols_on_feature:{col}",
                train_base,
                oos_base,
                y_train,
                y_oos,
                config,
            )
        )

    detail = pd.DataFrame(rows)
    detail["model_metric_value"] = model_metric
    if not np.isfinite(model_metric):
        detail["beats_model"] = False
        return (
            _summary_row(
                "2.1",
                "Качество работы модели / точность",
                "Ключевая метрика качества модели на OOS против базовых подходов",
                "gray",
                model_metric,
                "Metric must be finite",
                f"{metric_display_name(config.primary_metric)} не определена на OOS; "
                "baseline-сравнение невозможно.",
            ),
            detail.sort_values("metric_value", na_position="last").reset_index(drop=True),
        )
    detail["beats_model"] = detail["metric_value"] < (model_metric - config.baseline_tolerance)
    finite_detail = detail[np.isfinite(detail["metric_value"].astype("float64"))]
    if finite_detail.empty:
        return (
            _summary_row(
                "2.1",
                "Качество работы модели / точность",
                "Ключевая метрика качества модели на OOS против базовых подходов",
                "gray",
                model_metric,
                "At least one finite baseline metric is required",
                "Baseline-сравнение невозможно: метрика не определена для всех базовых подходов.",
            ),
            detail.sort_values("metric_value", na_position="last").reset_index(drop=True),
        )
    best = finite_detail.loc[finite_detail["metric_value"].idxmin()]
    light = "red" if bool(detail["beats_model"].any()) else "green"
    return (
        _summary_row(
            "2.1",
            "Качество работы модели / точность",
            "Ключевая метрика качества модели на OOS против базовых подходов",
            light,
            model_metric,
            "red: any baseline has lower error than the model; green: no baseline is better",
            f"Best baseline: {best['baseline']} = {best['metric_value']:.6g}; model = {model_metric:.6g}.",
        ),
        detail.sort_values("metric_value", na_position="last").reset_index(drop=True),
    )


def _baseline_row(
    name: str,
    pred: np.ndarray,
    y: np.ndarray,
    config: RegressionValidationConfig,
    baseline_type: str,
) -> Dict[str, Any]:
    return {
        "baseline": name,
        "baseline_type": baseline_type,
        "metric": metric_display_name(config.primary_metric),
        "metric_value": metric_value(y, _as_1d_float(pred, name), config.primary_metric, config.eps),
        "MAE": metric_value(y, _as_1d_float(pred, name), "mae", config.eps),
        "RMSE": metric_value(y, _as_1d_float(pred, name), "rmse", config.eps),
        "MAE_to_Mean": metric_value(y, _as_1d_float(pred, name), "mae_to_mean", config.eps),
    }


def _ols_on_baseline_row(
    name: str,
    train_base: np.ndarray,
    oos_base: np.ndarray,
    y_train: np.ndarray,
    y_oos: np.ndarray,
    config: RegressionValidationConfig,
) -> Dict[str, Any]:
    from sklearn.linear_model import LinearRegression

    train_arr = _as_1d_float(train_base, f"{name}.train_base")
    oos_arr = _as_1d_float(oos_base, f"{name}.oos_base")
    lr = LinearRegression()
    lr.fit(train_arr.reshape(-1, 1), y_train)
    pred = lr.predict(oos_arr.reshape(-1, 1))
    return _baseline_row(name, pred, y_oos, config, "ols_on_base_prediction")


def _mode_float(y: np.ndarray) -> float:
    s = pd.Series(y)
    mode = s.mode(dropna=True)
    return float(mode.iloc[0]) if not mode.empty else float(np.mean(y))


def _test_spearman(
    y: np.ndarray, pred: np.ndarray, config: RegressionValidationConfig
) -> Tuple[Dict[str, Any], pd.DataFrame]:
    if pd.Series(y).nunique(dropna=True) < 2 or pd.Series(pred).nunique(dropna=True) < 2:
        rho, pvalue = np.nan, np.nan
    else:
        rho, pvalue = stats.spearmanr(y, pred)
    rho = float(rho) if np.isfinite(rho) else np.nan
    if pd.isna(rho):
        light = "red"
    elif rho < config.spearman_yellow_min:
        light = "red"
    elif rho <= config.spearman_green_min:
        light = "yellow"
    else:
        light = "green"
    detail = pd.DataFrame(
        [{"spearman_rho": rho, "pvalue": float(pvalue) if np.isfinite(pvalue) else np.nan, "n": len(y)}]
    )
    return (
        _summary_row(
            "3.1",
            "Калибровка модели",
            "Spearman корреляция факта и прогноза на OOS",
            light,
            rho,
            "red: rho<0.2; yellow: 0.2<=rho<=0.3; green: rho>0.3",
            "Методика трактует высокий Spearman как хорошую связь факта и прогноза.",
        ),
        detail,
    )


def _test_mean_equality(
    y: np.ndarray,
    pred: np.ndarray,
    *,
    split_name: str,
    test_id: str,
    block: str,
    test_name: str,
    green_abs: float,
    yellow_abs: float,
    config: RegressionValidationConfig,
) -> Tuple[Dict[str, Any], pd.DataFrame]:
    mean_fact = float(np.mean(y))
    mean_pred = float(np.mean(pred))
    rel = (mean_pred - mean_fact) / abs(mean_fact) if abs(mean_fact) > config.eps else np.nan
    abs_rel = abs(rel) if not pd.isna(rel) else np.nan
    if pd.isna(abs_rel):
        light = "gray"
    elif abs_rel > yellow_abs + config.eps:
        light = "red"
    elif abs_rel > green_abs + config.eps:
        light = "yellow"
    else:
        light = "green"
    detail = pd.DataFrame(
        [
            {
                "split": split_name,
                "mean_fact": mean_fact,
                "mean_pred": mean_pred,
                "signed_rel_diff": rel,
                "abs_rel_diff": abs_rel,
                "n": len(y),
            }
        ]
    )
    return (
        _summary_row(
            test_id,
            block,
            test_name,
            light,
            abs_rel,
            f"green: |diff|<={green_abs:.0%}; yellow: |diff|<={yellow_abs:.0%}; red above",
            "Относительное отклонение считается как (mean(pred)-mean(fact))/abs(mean(fact)).",
        ),
        detail,
    )


def _test_regression_ftest(
    oos_df: pd.DataFrame,
    feature_cols: List[str],
    y: np.ndarray,
    config: RegressionValidationConfig,
) -> Tuple[Dict[str, Any], pd.DataFrame]:
    if not feature_cols:
        detail = pd.DataFrame()
        return (
            _summary_row(
                "4.3",
                "Спецификация модели",
                "Статистическая значимость регрессии",
                "gray",
                np.nan,
                "Need at least 1 feature",
                "F-test невозможен: нет факторов модели.",
            ),
            detail,
        )

    X = _encode_for_sklearn(oos_df[feature_cols], categorical_cols=config.categorical_cols)
    nunique = X.nunique(dropna=True)
    X = X.loc[:, nunique > 1]
    n = len(y)
    k = X.shape[1]
    if k < 1:
        detail = pd.DataFrame()
        return (
            _summary_row(
                "4.3",
                "Спецификация модели",
                "Статистическая значимость регрессии",
                "gray",
                np.nan,
                "Need at least 1 non-constant encoded feature",
                "F-test невозможен: все факторы константны после кодирования.",
            ),
            detail,
        )

    x_design = np.column_stack([np.ones(n), X.to_numpy(dtype="float64")])
    rank = int(np.linalg.matrix_rank(x_design))
    df_reg = max(rank - 1, 0)
    df_err = n - rank
    if df_reg < 1 or df_err < 1 or n <= rank:
        pvalue = np.nan
        f_stat = np.nan
        light = "gray"
        comment = "F-test невозможен: недостаточно степеней свободы для регрессии по факторам."
    else:
        y_mean = float(np.mean(y))
        beta, *_ = np.linalg.lstsq(x_design, y, rcond=None)
        fitted = x_design @ beta
        sse = float(np.sum((y - fitted) ** 2))
        sst = float(np.sum((y - y_mean) ** 2))
        ssr = max(sst - sse, 0.0)
        if sst <= config.eps:
            f_stat = np.nan
            pvalue = np.nan
            light = "gray"
            comment = "F-test невозможен: целевая переменная константна на OOS."
        elif sse <= config.eps:
            f_stat = np.inf
            pvalue = 0.0
        else:
            f_stat = (ssr / df_reg) / (sse / df_err)
            pvalue = float(stats.f.sf(f_stat, df_reg, df_err))
        if np.isfinite(pvalue):
            if pvalue > config.ftest_yellow_pvalue_max:
                light = "red"
            elif pvalue > config.ftest_green_pvalue_max:
                light = "yellow"
            else:
                light = "green"
            comment = (
                "OLS target ~ encoded model factors on OOS; p-value tests overall "
                "regression significance."
            )
    detail = pd.DataFrame(
        [
            {
                "f_stat": f_stat,
                "pvalue": pvalue,
                "n": n,
                "n_model_features": len(feature_cols),
                "n_encoded_non_constant_features": k,
                "design_rank": rank,
                "df_reg": df_reg,
                "df_err": df_err,
            }
        ]
    )
    return (
        _summary_row(
            "4.3",
            "Спецификация модели",
            "Статистическая значимость регрессии",
            light,
            pvalue,
            "red: p>5%; yellow: 1%<p<=5%; green: p<=1%",
            comment,
        ),
        detail,
    )


def _test_vif(
    train_df: pd.DataFrame,
    feature_cols: List[str],
    config: RegressionValidationConfig,
) -> Tuple[Dict[str, Any], pd.DataFrame]:
    if len(feature_cols) < 2:
        detail = pd.DataFrame()
        return (
            _summary_row(
                "4.4",
                "Спецификация модели",
                "Мультиколлинеарность факторов (VIF)",
                "gray",
                np.nan,
                "Need at least 2 features",
                "Недостаточно факторов для VIF.",
            ),
            detail,
        )
    sample = _sample_frame(train_df[feature_cols], config.vif_sample_size, config.random_state)
    X = _encode_for_sklearn(sample, categorical_cols=config.categorical_cols)
    nunique = X.nunique(dropna=True)
    X = X.loc[:, nunique > 1]
    if config.vif_max_features is not None and X.shape[1] > config.vif_max_features:
        variances = X.var().sort_values(ascending=False)
        X = X[variances.head(config.vif_max_features).index]
    if X.shape[1] < 2:
        detail = pd.DataFrame()
        return (
            _summary_row(
                "4.4",
                "Спецификация модели",
                "Мультиколлинеарность факторов (VIF)",
                "gray",
                np.nan,
                "Need at least 2 non-constant encoded features",
                "После удаления констант осталось меньше двух факторов.",
            ),
            detail,
        )

    from sklearn.linear_model import LinearRegression

    rows = []
    values = X.to_numpy(dtype="float64")
    cols = list(X.columns)
    for i, col in enumerate(cols):
        y_col = values[:, i]
        X_other = np.delete(values, i, axis=1)
        try:
            reg = LinearRegression().fit(X_other, y_col)
            r2 = float(reg.score(X_other, y_col))
            vif = float("inf") if r2 >= 1.0 else float(1.0 / max(1.0 - r2, config.eps))
        except Exception:
            vif = np.nan
        if pd.isna(vif):
            light = "gray"
        elif vif > config.vif_red_min:
            light = "red"
        elif vif > config.vif_yellow_min:
            light = "yellow"
        else:
            light = "green"
        rows.append({"feature": col, "VIF": vif, "traffic_light_code": light, "traffic_light": TRAFFIC_RU[light]})

    detail = pd.DataFrame(rows).sort_values("VIF", ascending=False, na_position="last").reset_index(drop=True)
    valid = detail[detail["traffic_light_code"].isin(["green", "yellow", "red"])]
    red_share = float(valid["traffic_light_code"].eq("red").mean()) if len(valid) else 0.0
    yellow_share = float(valid["traffic_light_code"].eq("yellow").mean()) if len(valid) else 0.0
    if red_share >= config.vif_bad_share_red_min:
        light = "red"
    elif red_share > 0 or yellow_share >= config.vif_bad_share_yellow_min:
        light = "yellow"
    else:
        light = "green"
    return (
        _summary_row(
            "4.4",
            "Спецификация модели",
            "Мультиколлинеарность факторов (VIF)",
            light,
            max(red_share, yellow_share),
            "red: >=20% red factors; yellow: any red<20% or >=20% yellow factors; green: no red and yellow<20%",
            _vif_comment(config, X.shape[1]),
        ),
        detail,
    )


def _vif_comment(config: RegressionValidationConfig, n_features: int) -> str:
    if config.vif_max_features is None:
        return f"VIF computed on all {n_features} encoded non-constant train features."
    return f"VIF computed on up to {config.vif_max_features} encoded non-constant train features."


def _test_metric_stability(
    metrics_df: pd.DataFrame,
    test_id: str,
    direction_label: str,
    base_split: str,
    compare_split: str,
    config: RegressionValidationConfig,
) -> Tuple[Dict[str, Any], pd.DataFrame]:
    base = metrics_df[metrics_df["split"].eq(base_split)]
    comp = metrics_df[metrics_df["split"].eq(compare_split)]
    if base.empty or comp.empty:
        detail = pd.DataFrame()
        return (
            _summary_row(
                test_id,
                "Стабильность модели",
                f"Стабильность ключевой метрики {direction_label}",
                "yellow",
                np.nan,
                "Both splits required",
                f"Не найден один из сплитов: {base_split}, {compare_split}.",
            ),
            detail,
        )
    base_value = float(base.iloc[0]["primary_metric_value"])
    comp_value = float(comp.iloc[0]["primary_metric_value"])
    deterioration = comp_value - base_value
    rel = deterioration / abs(base_value) if abs(base_value) > config.eps else np.nan
    if pd.isna(rel):
        light = "gray"
    elif (
        deterioration > config.stability_abs_red_min + config.eps
        and rel > config.stability_rel_red_min + config.eps
    ):
        light = "red"
    elif (
        deterioration > config.stability_abs_yellow_min + config.eps
        and rel > config.stability_rel_yellow_min + config.eps
    ):
        light = "yellow"
    else:
        light = "green"
    detail = pd.DataFrame(
        [
            {
                "metric": metric_display_name(config.primary_metric),
                "base_split": base_split,
                "compare_split": compare_split,
                "base_value": base_value,
                "compare_value": comp_value,
                "abs_deterioration": deterioration,
                "rel_deterioration": rel,
            }
        ]
    )
    threshold = "red: abs>0.25 and rel>30%; yellow: abs>0.15 and rel>20%; green otherwise"
    return (
        _summary_row(
            test_id,
            "Стабильность модели",
            f"Стабильность ключевой метрики {direction_label}",
            light,
            rel,
            threshold,
            "Для MAE/RMSE/MAE-to-Mean ухудшение = рост ошибки на сравниваемом сплите.",
        ),
        detail,
    )


def _psi_for_feature(
    train_s: pd.Series,
    compare_s: pd.Series,
    feature: str,
    compare_split: str,
    config: RegressionValidationConfig,
    force_discrete: bool = False,
) -> Dict[str, Any]:
    train_s = pd.Series(train_s).reset_index(drop=True)
    compare_s = pd.Series(compare_s).reset_index(drop=True)
    kind = _feature_kind(train_s, force_discrete=force_discrete)
    if kind == "continuous":
        train_labels, compare_labels, n_buckets = _continuous_bucket_labels(train_s, compare_s, config)
    else:
        train_labels, compare_labels, n_buckets = _discrete_bucket_labels(train_s, compare_s, config)
    psi = _psi_from_labels(train_labels, compare_labels, config.eps)
    light = "yellow" if psi >= config.feature_psi_yellow_min else "green"
    return {
        "feature": feature,
        "compare_split": compare_split,
        "kind": kind,
        "PSI": psi,
        "traffic_light_code": light,
        "traffic_light": TRAFFIC_RU[light],
        "n_train": len(train_s),
        "n_compare": len(compare_s),
        "train_missing_share": float(train_s.isna().mean()),
        "compare_missing_share": float(compare_s.isna().mean()),
        "n_buckets": n_buckets,
    }


def _feature_kind(s: pd.Series, force_discrete: bool = False) -> str:
    if force_discrete:
        return "discrete"
    non_missing = s.dropna()
    if non_missing.empty:
        return "discrete"
    if not pd.api.types.is_numeric_dtype(non_missing):
        return "discrete"
    top10_share = non_missing.value_counts(normalize=True).head(10).sum()
    return "discrete" if top10_share >= 0.80 else "continuous"


def _discrete_bucket_labels(
    train_s: pd.Series, compare_s: pd.Series, config: RegressionValidationConfig
) -> Tuple[pd.Series, pd.Series, int]:
    marker_missing = "__MISSING__"
    marker_other = "__OTHER__"
    train_key = train_s.astype("object").where(~train_s.isna(), marker_missing).map(str)
    compare_key = compare_s.astype("object").where(~compare_s.isna(), marker_missing).map(str)

    buckets = _train_discrete_buckets(train_key, config.psi_min_bucket_share, marker_missing)

    def assign_initial(keys: pd.Series) -> pd.Series:
        value_to_bucket = {}
        for i, bucket in enumerate(buckets):
            for value in bucket:
                value_to_bucket[value] = f"bucket_{i + 1:03d}"

        def one(value: str) -> str:
            if value == marker_missing:
                return marker_missing
            return value_to_bucket.get(value, marker_other)

        return keys.map(one)

    train_initial = assign_initial(train_key)
    compare_initial = assign_initial(compare_key)
    train_labels, compare_labels = _merge_small_compare_buckets(
        train_initial,
        compare_initial,
        config.psi_min_bucket_share,
        marker_missing,
    )
    categories = set(train_labels.unique()).union(compare_labels.unique())
    return train_labels, compare_labels, len(categories)


def _train_discrete_buckets(
    train_key: pd.Series, min_share: float, marker_missing: str
) -> List[set[str]]:
    shares = train_key[train_key != marker_missing].value_counts(normalize=True)
    if shares.empty:
        return []

    buckets: List[set[str]] = []
    pending: List[str] = []
    pending_share = 0.0
    for value, share in shares.items():
        share = float(share)
        if share >= min_share and not pending:
            buckets.append({str(value)})
            continue
        pending.append(str(value))
        pending_share += share
        if pending_share >= min_share:
            buckets.append(set(pending))
            pending = []
            pending_share = 0.0

    if pending:
        if buckets:
            buckets[-1].update(pending)
        else:
            buckets.append(set(pending))
    return buckets


def _merge_small_compare_buckets(
    train_labels: pd.Series,
    compare_labels: pd.Series,
    min_share: float,
    marker_missing: str,
) -> Tuple[pd.Series, pd.Series]:
    ordered = [
        x
        for x in pd.unique(pd.concat([train_labels, compare_labels], ignore_index=True))
        if x != marker_missing
    ]
    groups: List[List[str]] = [[x] for x in ordered]
    compare_non_missing = compare_labels[compare_labels != marker_missing]
    if compare_non_missing.empty or len(groups) <= 1:
        return train_labels, compare_labels

    def group_share(group: List[str]) -> float:
        return float(compare_non_missing.isin(group).mean())

    changed = True
    while changed and len(groups) > 1:
        changed = False
        for i, group in enumerate(groups):
            if group_share(group) >= min_share:
                continue
            if i < len(groups) - 1:
                groups[i + 1] = group + groups[i + 1]
                del groups[i]
            else:
                groups[i - 1].extend(group)
                del groups[i]
            changed = True
            break

    mapping = {}
    for i, group in enumerate(groups):
        label = f"bucket_{i + 1:03d}"
        for old_label in group:
            mapping[old_label] = label

    def apply_mapping(s: pd.Series) -> pd.Series:
        return s.map(lambda x: marker_missing if x == marker_missing else mapping.get(x, x))

    return apply_mapping(train_labels), apply_mapping(compare_labels)


def _continuous_bucket_labels(
    train_s: pd.Series, compare_s: pd.Series, config: RegressionValidationConfig
) -> Tuple[pd.Series, pd.Series, int]:
    train_num = pd.to_numeric(train_s, errors="coerce")
    compare_num = pd.to_numeric(compare_s, errors="coerce")
    edges = _median_split_edges(train_num, compare_num, config)
    bins = [-np.inf] + edges + [np.inf]

    def labels(x: pd.Series) -> pd.Series:
        out = pd.cut(x, bins=bins, include_lowest=True, duplicates="drop").astype("object")
        out = out.where(~x.isna(), "__MISSING__").map(str)
        return out

    train_labels = labels(train_num)
    compare_labels = labels(compare_num)
    n_buckets = len(set(train_labels.unique()).union(compare_labels.unique()))
    return train_labels, compare_labels, n_buckets


def _median_split_edges(
    train_num: pd.Series, compare_num: pd.Series, config: RegressionValidationConfig
) -> List[float]:
    tr = train_num.dropna().astype("float64")
    cp = compare_num.dropna().astype("float64")
    if tr.nunique() <= 1 or len(tr) == 0 or len(cp) == 0:
        return []
    edges: List[float] = []
    changed = True
    while changed and len(edges) + 1 < config.psi_max_bins:
        changed = False
        bounds = [-np.inf] + edges + [np.inf]
        for lo, hi in zip(bounds[:-1], bounds[1:]):
            tr_bin = tr[(tr > lo) & (tr <= hi)]
            cp_bin = cp[(cp > lo) & (cp <= hi)]
            if tr_bin.nunique() <= 1 or cp_bin.empty:
                continue
            thr = float(tr_bin.median())
            if not (lo < thr < hi):
                continue
            tr_left = ((tr > lo) & (tr <= thr)).mean()
            tr_right = ((tr > thr) & (tr <= hi)).mean()
            cp_left = ((cp > lo) & (cp <= thr)).mean()
            cp_right = ((cp > thr) & (cp <= hi)).mean()
            if min(tr_left, tr_right, cp_left, cp_right) >= config.psi_min_bucket_share:
                edges.append(thr)
                edges = sorted(set(edges))
                changed = True
                break
    return edges


def _psi_from_labels(train_labels: pd.Series, compare_labels: pd.Series, eps: float) -> float:
    cats = sorted(set(train_labels.unique()).union(compare_labels.unique()))
    train_counts = train_labels.value_counts(normalize=True)
    compare_counts = compare_labels.value_counts(normalize=True)
    psi = 0.0
    for cat in cats:
        a = max(float(train_counts.get(cat, 0.0)), eps)
        b = max(float(compare_counts.get(cat, 0.0)), eps)
        psi += (a - b) * math.log(a / b)
    return float(psi)


def _sample_frame(df: pd.DataFrame, max_n: Optional[int], seed: int) -> pd.DataFrame:
    if max_n is None or max_n <= 0 or len(df) <= max_n:
        return df.reset_index(drop=True)
    return df.sample(n=max_n, random_state=seed).reset_index(drop=True)


def _sample_two_frames(
    left: pd.DataFrame, right: pd.DataFrame, max_total: Optional[int], seed: int
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if max_total is None or max_total <= 0 or len(left) + len(right) <= max_total:
        return left.reset_index(drop=True), right.reset_index(drop=True)
    total = len(left) + len(right)
    n_left = max(2, int(max_total * len(left) / total))
    n_right = max(2, max_total - n_left)
    n_left = min(n_left, len(left))
    n_right = min(n_right, len(right))
    return (
        left.sample(n=n_left, random_state=seed).reset_index(drop=True),
        right.sample(n=n_right, random_state=seed + 1).reset_index(drop=True),
    )


def _encode_for_sklearn(
    df: pd.DataFrame, categorical_cols: Optional[Iterable[str]] = None
) -> pd.DataFrame:
    out = pd.DataFrame(index=df.index)
    categorical_set = set(categorical_cols or [])
    for col in df.columns:
        s = df[col]
        if pd.api.types.is_datetime64_any_dtype(s):
            out[col] = pd.to_datetime(s).astype("int64").astype("float64")
        elif col in categorical_set:
            labels, _ = pd.factorize(s.astype("object").where(~s.isna(), "__MISSING__").map(str))
            out[col] = labels.astype("float64")
        elif pd.api.types.is_bool_dtype(s) or _is_category_dtype(s):
            labels, _ = pd.factorize(s.astype("object").where(~s.isna(), "__MISSING__").map(str))
            out[col] = labels.astype("float64")
        elif pd.api.types.is_numeric_dtype(s):
            out[col] = pd.to_numeric(s, errors="coerce").astype("float64")
        else:
            labels, _ = pd.factorize(s.astype("object").where(~s.isna(), "__MISSING__").map(str))
            out[col] = labels.astype("float64")
        out[col] = out[col].replace([np.inf, -np.inf], np.nan)
        out[col] = out[col].fillna(0.0 if out[col].isna().all() else out[col].median())
    return out


def _encode_train_apply(
    train: pd.DataFrame,
    other: pd.DataFrame,
    categorical_cols: Optional[Iterable[str]] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    tr = pd.DataFrame(index=train.index)
    ot = pd.DataFrame(index=other.index)
    categorical_set = set(categorical_cols or [])
    for col in train.columns:
        s_tr = train[col]
        s_ot = other[col]
        if pd.api.types.is_datetime64_any_dtype(s_tr):
            tr[col] = pd.to_datetime(s_tr).astype("int64").astype("float64")
            ot[col] = pd.to_datetime(s_ot).astype("int64").astype("float64")
        elif col in categorical_set or pd.api.types.is_bool_dtype(s_tr) or _is_category_dtype(s_tr):
            keys = s_tr.astype("object").where(~s_tr.isna(), "__MISSING__").map(str)
            categories = {v: i for i, v in enumerate(pd.unique(keys))}
            tr[col] = keys.map(categories).astype("float64")
            ot_key = s_ot.astype("object").where(~s_ot.isna(), "__MISSING__").map(str)
            ot[col] = ot_key.map(categories).fillna(-1).astype("float64")
        elif pd.api.types.is_numeric_dtype(s_tr):
            tr[col] = pd.to_numeric(s_tr, errors="coerce").astype("float64")
            ot[col] = pd.to_numeric(s_ot, errors="coerce").astype("float64")
        else:
            keys = s_tr.astype("object").where(~s_tr.isna(), "__MISSING__").map(str)
            categories = {v: i for i, v in enumerate(pd.unique(keys))}
            tr[col] = keys.map(categories).astype("float64")
            ot_key = s_ot.astype("object").where(~s_ot.isna(), "__MISSING__").map(str)
            ot[col] = ot_key.map(categories).fillna(-1).astype("float64")
        fill = 0.0 if tr[col].isna().all() else float(tr[col].median())
        tr[col] = tr[col].replace([np.inf, -np.inf], np.nan).fillna(fill)
        ot[col] = ot[col].replace([np.inf, -np.inf], np.nan).fillna(fill)
    return tr, ot


def _is_category_dtype(s: pd.Series) -> bool:
    return isinstance(s.dtype, pd.CategoricalDtype)


def _block_summary(test_summary: pd.DataFrame) -> pd.DataFrame:
    rows = []
    scoring_tests = test_summary[~test_summary["informative"].fillna(False)]
    for block, part in scoring_tests.groupby("block", sort=False):
        if block == "Стабильность модели":
            light = _stability_block_light(part)
        else:
            light = _worst_light(part["traffic_light_code"].tolist())
        rows.append(
            {
                "block": block,
                "traffic_light_code": light,
                "traffic_light": TRAFFIC_RU[light],
                "tests": ", ".join(part["test_id"].astype(str).tolist()),
            }
        )
    return pd.DataFrame(rows)


def _stability_block_light(part: pd.DataFrame) -> str:
    t51 = part.loc[part["test_id"].astype(str).eq("5.1"), "traffic_light_code"]
    other = part.loc[~part["test_id"].astype(str).eq("5.1"), "traffic_light_code"]
    t51_light = t51.iloc[0] if not t51.empty else "gray"
    other_worst = _worst_light(other.tolist())
    if t51_light == "gray":
        return other_worst
    if other_worst == "gray":
        return t51_light
    matrix = {
        ("green", "green"): "green",
        ("yellow", "green"): "yellow",
        ("red", "green"): "red",
        ("green", "yellow"): "green",
        ("yellow", "yellow"): "yellow",
        ("red", "yellow"): "red",
        ("green", "red"): "yellow",
        ("yellow", "red"): "red",
        ("red", "red"): "red",
    }
    return matrix[(t51_light, other_worst)]


def _methodology_map(config: RegressionValidationConfig) -> pd.DataFrame:
    return pd.DataFrame(
        [
            ("1.1", "Качество разбиения train/OOS", "Gini split-classifier vs 200 random shuffles by default; q thresholds 0.95/0.99."),
            ("1.2", "PSI факторов OOS/OOT к train", "Фактор yellow при PSI>=0.2; тест yellow если >20% yellow факторов."),
            ("2.1", "Ключевая метрика vs baseline", f"Metric={metric_display_name(config.primary_metric)}; red если lower-is-better ошибка baseline ниже ошибки модели."),
            ("2.2", "Bootstrap CI ключевой метрики", "Информативный тест; в итоговый светофор не входит."),
            ("3.1", "Spearman факт-прогноз OOS", "red <0.2; yellow 0.2..0.3; green >0.3."),
            ("3.2", "Среднее forecast/fact OOS", "green |diff|<=15%; yellow <=30%; red >30%."),
            ("4.3", "F-test target~model factors", "red p>5%; yellow 1%..5%; green <=1%."),
            ("4.4", "VIF", "factor red VIF>5, yellow 3..5; aggregate by 20% share rule."),
            ("5.1", "Стабильность OOS->OOT", "red abs>0.25 and rel>30%; yellow abs>0.15 and rel>20%."),
            ("5.2", "Стабильность train->OOS", "same thresholds as 5.1."),
            ("5.3", "Среднее forecast/fact OOT", "green |diff|<=25%; yellow <=50%; red >50%."),
        ],
        columns=["test_id", "methodology", "traffic_light_rule"],
    )


def _write_excel_report(
    *,
    output_path: Path,
    model_name: str,
    overall_light: str,
    block_summary: pd.DataFrame,
    test_summary: pd.DataFrame,
    details: Dict[str, pd.DataFrame],
    config: RegressionValidationConfig,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        pd.DataFrame({"_": []}).to_excel(writer, sheet_name="Итог", index=False)
        block_summary.to_excel(writer, sheet_name="Блоки", index=False)
        test_summary.to_excel(writer, sheet_name="Светофоры", index=False)
        for name, df in details.items():
            df.to_excel(writer, sheet_name=_safe_sheet_name(name), index=False)

    from openpyxl import load_workbook
    from openpyxl.formatting.rule import ColorScaleRule
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = load_workbook(output_path)
    ws = wb["Итог"]
    ws.delete_rows(1, ws.max_row)
    ws["A1"] = "Валидационный отчет регрессионной модели"
    ws["A1"].font = Font(bold=True, size=16, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor="1F4E78")
    ws.merge_cells("A1:H1")
    ws["A2"] = "Модель"
    ws["B2"] = model_name
    ws["A3"] = "Дата формирования"
    ws["B3"] = _dt.datetime.now().isoformat(timespec="seconds")
    ws["A4"] = "Ключевая метрика"
    ws["B4"] = metric_display_name(config.primary_metric)
    ws["A5"] = "Итоговый светофор"
    ws["B5"] = TRAFFIC_RU[overall_light]
    ws["B5"].fill = PatternFill("solid", fgColor=TRAFFIC_HEX[overall_light])
    ws["B5"].font = Font(bold=True, color="FFFFFF" if overall_light in {"red", "green"} else "000000")

    ws["A7"] = "Светофоры по блокам"
    ws["A7"].font = Font(bold=True)
    _write_df_to_sheet(ws, block_summary.drop(columns=["traffic_light_code"]), start_row=8)

    start = 11 + len(block_summary)
    ws[f"A{start}"] = "Светофоры по тестам"
    ws[f"A{start}"].font = Font(bold=True)
    view_cols = [
        "test_id",
        "block",
        "test_name",
        "traffic_light",
        "metric_value",
        "threshold",
        "informative",
        "comment",
    ]
    _write_df_to_sheet(ws, test_summary[view_cols], start_row=start + 1)
    ws.freeze_panes = "A8"

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        if ws.max_row >= 1:
            for cell in ws[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="4472C4")
                cell.alignment = Alignment(horizontal="left", vertical="center")
        ws.auto_filter.ref = ws.dimensions
        if sheet_name != "Итог":
            ws.freeze_panes = "A2"
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and cell.value in TRAFFIC_RU.values():
                    code = {v: k for k, v in TRAFFIC_RU.items()}[cell.value]
                    cell.fill = PatternFill("solid", fgColor=TRAFFIC_HEX[code])
                    cell.font = Font(bold=True, color="FFFFFF" if code in {"green", "red"} else "000000")
                cell.alignment = Alignment(wrap_text=True, vertical="top")
        for col_idx, col in enumerate(ws.columns, start=1):
            letter = get_column_letter(col_idx)
            max_len = max((len(str(c.value)) if c.value is not None else 0 for c in col), default=10)
            ws.column_dimensions[letter].width = min(max(max_len + 2, 10), 76)
        headers = [c.value for c in ws[1]]
        for metric_col in ("PSI", "VIF", "metric_value", "primary_metric_value", "abs_rel_diff", "pvalue"):
            if metric_col in headers and ws.max_row > 1:
                idx = headers.index(metric_col) + 1
                letter = get_column_letter(idx)
                ws.conditional_formatting.add(
                    f"{letter}2:{letter}{ws.max_row}",
                    ColorScaleRule(
                        start_type="min",
                        start_color="63BE7B",
                        mid_type="percentile",
                        mid_value=70,
                        mid_color="FFEB84",
                        end_type="max",
                        end_color="F8696B",
                    ),
                )
    wb.save(output_path)


def _write_df_to_sheet(ws: Any, df: pd.DataFrame, start_row: int) -> None:
    for j, col in enumerate(df.columns, start=1):
        ws.cell(start_row, j, col)
    for i, (_, row) in enumerate(df.iterrows(), start=start_row + 1):
        for j, col in enumerate(df.columns, start=1):
            value = row[col]
            if pd.isna(value):
                value = None
            ws.cell(i, j, value)


def _safe_sheet_name(name: str) -> str:
    bad = set(r'[]:*?/\\')
    clean = "".join("_" if ch in bad else ch for ch in name)
    return clean[:31]
