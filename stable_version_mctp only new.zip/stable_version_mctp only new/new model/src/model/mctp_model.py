import json
import os
from pathlib import Path
from typing import Union

from catboost import CatBoostClassifier

import fastjsonschema
import pandas as pd
from pyframework.handler.decorator import request_handler
from pyframework.handler.generic_json_model import GenericJsonModel

from src.schemas import INPUT_SCHEMA, INPUT_SCHEMA_VALIDATOR
from src.utils import MEF_LOGGER


class MCTPMatchingModel(GenericJsonModel):
    def __init__(self):
        self.load_params()

        self.load_model()

        MEF_LOGGER.info("MODEL IS READY!")
        super().__init__()

    @request_handler
    async def predict(self, initial_data: Union[dict, list], **context) -> Union[dict, list]:

        try:
            INPUT_SCHEMA_VALIDATOR(initial_data)
        except fastjsonschema.JsonSchemaException as e:
            MEF_LOGGER.error(
                f"""
                    Invalid input data format. Expected:
                    {json.dumps(INPUT_SCHEMA, indent=4)}.
                    Error:
                    {e}
                """
            )

        UID = initial_data["UID"]
        MEF_LOGGER.info(f"[UID: {UID}]: Start processing request")

        response_json = {
            "UID": UID,
            "sdDt": initial_data["sdDt"],
            "sdText": initial_data["sdText"],
            "problems": [],
        }

        features_dataset = self.create_features_dataset(initial_data)
        if len(features_dataset) == 0:
            MEF_LOGGER.info(f"[UID: {UID}]: No candidates found")
            MEF_LOGGER.info(f"[UID: {UID}]: Constracting response")
            MEF_LOGGER.info(f"[UID: {UID}]: Finished")
            return response_json

        MEF_LOGGER.info(f"[UID: {UID}]: Catboost predict")
        detailed_report = await self.catboost_predict(features_dataset)

        MEF_LOGGER.info(f"[UID: {UID}]: Constracting response")
        for _, data in detailed_report.iterrows():
            response_json["problems"].append(
                {
                    "problemProba": data["predicted_proba"],
                    "problemID": data["problem"],
                    "problemDescription": data["desc_candidate_problem"]
                    if data["desc_candidate_problem"] != None
                    else "Не задано",
                    "problemTopic": data["theme_problem"]
                    if data["theme_problem"] != None
                    else "Не задано",
                    "solvingProblem": data["decision_problem"]
                    if data["decision_problem"] != None
                    else "Не задано",
                }
            )

        MEF_LOGGER.info(f"[UID: {UID}]: Finished")
        return response_json

    def load_params(self):
        MEF_LOGGER.info("PREPARING MODEL PARAMS")
        self.static_files_dir = Path(os.getenv("STATIC_FILES_DIR", "src/static"))

        self.best_model_path = str(self.static_files_dir / "CatBoost.10.batch5.json")

        self.selected_threshold = int(os.getenv("SELECTED_THRESHOLD", 0))

        self.n_head = int(os.getenv("N_HEAD", 4))

        self.output_cols = [
            "id_sd",
            "predicted_proba",
            "problem",
            "description",
            "desc_candidate_problem",
            "theme_problem",
            "decision_problem",
        ]
        MEF_LOGGER.info("MODEL PARAMS PREPARED")

    def load_model(self):
        MEF_LOGGER.info("LOADING MODEL")
        self.best_model = CatBoostClassifier()
        self.best_model.load_model(self.best_model_path, format="json")

        self.feature_list = self.best_model.feature_names_
        MEF_LOGGER.info("MODEL LOADED")

    def create_features_dataset(self, initial_data: dict) -> pd.DataFrame:
        features_rows = []
        for candidate in initial_data["candidates"]:
            model_features = candidate["modelFeatures"]
            problem = model_features.get("problem", candidate["problemID"])

            features_rows.append(
                {
                    "current_id": initial_data["UID"],
                    "problem_true": -1,
                    "date_time": initial_data["sdDt"],
                    "id_sd": candidate["CandidateSDID"],
                    "description": initial_data["sdText"],
                    "problem": problem,
                    "similarity_d_p": model_features["similarity_d_p"],
                    "description_candidate": None,
                    "desc_candidate_problem": candidate["problemDescription"],
                    "time_delta": model_features["time_delta"],
                    "count_problems": model_features["count_problems"],
                    "words_match": model_features["words_match"],
                    "words_count": model_features["words_count"],
                    "target": 0,
                    "has_problem": 0,
                    "candidate_desc_length": model_features["candidate_desc_length"],
                    "time_delta_log": model_features["time_delta_log"],
                    "words_match_path_path": model_features["words_match_path_path"],
                    "words_match_path": model_features["words_match_path"],
                    "path_true": None,
                    "theme_problem": candidate["problemTopic"],
                    "decision_problem": candidate["solvingProblem"],
                    "unique_problems_count": model_features["unique_problems_count"],
                }
            )

        return pd.DataFrame(features_rows)

    async def catboost_predict(self, features_dataset: pd.DataFrame) -> pd.DataFrame:
        features_dataset["predicted_proba"] = self.best_model.predict_proba(
            features_dataset[self.feature_list]
        )[:, 1]
        features_dataset["has_problem"] = features_dataset["problem_true"].apply(
            lambda x: 0 if x == -1 else 1
        )
        features_dataset_p = (
            features_dataset.sort_values("predicted_proba", ascending=False)
            .groupby(["current_id", "problem"])
            .first()
            .reset_index()
        )

        # Для каждого обращения берем до 10 кандидатов (с максимальной вероятностью)
        top10_candidates = (
            features_dataset_p.sort_values("predicted_proba", ascending=False)
            .groupby("current_id")
            .head(self.n_head)
        )

        # Оставляем только кандидатов, прошедших порог
        above_threshold_candidates = top10_candidates[
            top10_candidates["predicted_proba"] >= self.selected_threshold
        ].copy()
        above_threshold_candidates = above_threshold_candidates[
            above_threshold_candidates["problem"] != -1
        ].copy()
        above_threshold_candidates["above_threshold"] = 1

        # Создаем детальный отчет
        detailed_report = above_threshold_candidates[
            [
                "current_id",
                "predicted_proba",
                "above_threshold",
                "target",
                "has_problem",
            ]
        ].copy()

        # Добавляем дополнительные колонки если они существуют в данных
        additional_columns = [
            "problem",
            "problem_true",
            "description",
            "description_candidate",
            "desc_candidate_problem",
            "theme_problem",
            "decision_problem",
            "id_sd",
        ]

        for col in additional_columns:
            detailed_report[col] = above_threshold_candidates[col]

        # Сортируем по убыванию вероятности
        detailed_report = detailed_report.sort_values("predicted_proba", ascending=False)
        detailed_report = detailed_report[self.output_cols].copy()

        return detailed_report
