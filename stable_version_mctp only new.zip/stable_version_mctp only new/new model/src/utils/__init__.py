from .logger import MEF_LOGGER

__all__ = [
    "MEF_LOGGER"
]
