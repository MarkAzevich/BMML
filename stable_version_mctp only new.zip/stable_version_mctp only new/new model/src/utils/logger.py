import logging

MEF_LOGGER = logging.getLogger(__name__)