import fastjsonschema


PROBLEM_ID_SCHEMA = {
    "type": ["number", "string"],
    "description": "ID кандидатной проблемы",
}


MODEL_FEATURES_SCHEMA = {
    "type": "object",
    "additionalProperties": True,
    "properties": {
        "problem": PROBLEM_ID_SCHEMA,
        "similarity_d_p": {"type": "number"},
        "time_delta": {"type": ["number", "null"]},
        "count_problems": {"type": "number"},
        "words_match": {"type": "number"},
        "words_count": {"type": "number"},
        "candidate_desc_length": {"type": "number"},
        "time_delta_log": {"type": "number"},
        "words_match_path_path": {"type": "number"},
        "words_match_path": {"type": "number"},
        "unique_problems_count": {"type": "number"},
    },
    "required": [
        "problem",
        "similarity_d_p",
        "time_delta",
        "count_problems",
        "words_match",
        "words_count",
        "candidate_desc_length",
        "time_delta_log",
        "words_match_path_path",
        "words_match_path",
        "unique_problems_count",
    ],
}


INPUT_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "UID": {
            "type": "number",
            "description": "Уникальный идентификатор запроса",
            "minimum": 0,
            "maximum": 1000000000,
        },
        "sdDt": {
            "type": "string",
            "description": "Дата обращения",
            "maxLength": 10,
        },
        "sdText": {
            "type": "string",
            "description": "Текст обращения",
            "maxLength": 3000,
        },
        "candidates": {
            "type": "array",
            "description": "Кандидаты после preprocessing",
            "items": {
                "type": "object",
                "additionalProperties": True,
                "properties": {
                    "problemID": PROBLEM_ID_SCHEMA,
                    "CandidateSDID": {"type": "string"},
                    "problemDescription": {"type": ["string", "number", "null"]},
                    "problemTopic": {"type": ["string", "number", "null"]},
                    "solvingProblem": {"type": ["string", "number", "null"]},
                    "modelFeatures": MODEL_FEATURES_SCHEMA,
                },
                "required": [
                    "problemID",
                    "CandidateSDID",
                    "problemDescription",
                    "problemTopic",
                    "solvingProblem",
                    "modelFeatures",
                ],
            },
        },
    },
    "required": ["UID", "sdDt", "sdText", "candidates"],
}


INPUT_SCHEMA_VALIDATOR = fastjsonschema.compile(INPUT_SCHEMA)
