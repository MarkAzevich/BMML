from pyframework import app
from pyframework.config import generic_json

from src.model import MCTPMatchingModel


def main() -> None:
    app.run(model=MCTPMatchingModel(), configs={generic_json,})

if __name__ == "__main__":
    main()
