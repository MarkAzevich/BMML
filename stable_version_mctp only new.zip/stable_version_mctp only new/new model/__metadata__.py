__all__ = [
    '__title__',
    '__version__'
]

__title__ = 'MCTP Issue Matching Model'
__version__ = '1.0.0'