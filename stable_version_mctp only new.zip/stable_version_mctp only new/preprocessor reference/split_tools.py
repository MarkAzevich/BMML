import importlib
import math
import os
import sys
import types
from datetime import timedelta
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CURRENT_MODEL_DIR = PROJECT_ROOT / "current model"
NEW_MODEL_DIR = PROJECT_ROOT / "new model"
PREPROCESSED_JSON_PATH = Path(__file__).resolve().parent / "preprocessed_payload.json"


CATBOOST_FEATURE_KEYS = [
    "similarity_d_p",
    "count_problems",
    "time_delta_log",
    "words_match_path_path",
    "candidate_desc_length",
    "time_delta",
    "unique_problems_count",
    "words_count",
    "words_match_path",
    "words_match",
]


def install_pyframework_stub() -> None:
    if "pyframework.handler.generic_json_model" in sys.modules:
        return

    pyframework = types.ModuleType("pyframework")
    handler = types.ModuleType("pyframework.handler")
    decorator = types.ModuleType("pyframework.handler.decorator")
    generic_json_model = types.ModuleType("pyframework.handler.generic_json_model")
    config = types.ModuleType("pyframework.config")
    app = types.ModuleType("pyframework.app")

    def request_handler(func):
        return func

    class GenericJsonModel:
        def __init__(self, *args, **kwargs):
            super().__init__()

    def run(*args, **kwargs):
        raise RuntimeError("pyframework app.run is not available in local checks")

    decorator.request_handler = request_handler
    generic_json_model.GenericJsonModel = GenericJsonModel
    config.generic_json = object()
    app.run = run
    pyframework.app = app
    pyframework.config = config
    pyframework.handler = handler
    handler.decorator = decorator
    handler.generic_json_model = generic_json_model

    sys.modules["pyframework"] = pyframework
    sys.modules["pyframework.app"] = app
    sys.modules["pyframework.config"] = config
    sys.modules["pyframework.handler"] = handler
    sys.modules["pyframework.handler.decorator"] = decorator
    sys.modules["pyframework.handler.generic_json_model"] = generic_json_model


def clear_src_modules() -> None:
    for module_name in list(sys.modules):
        if module_name == "src" or module_name.startswith("src."):
            del sys.modules[module_name]


def load_model_class(project_dir: Path):
    install_pyframework_stub()
    clear_src_modules()
    project_dir = project_dir.resolve()
    sys.path.insert(0, str(project_dir))
    try:
        module = importlib.import_module("src.model")
        return module.MCTPMatchingModel
    finally:
        sys.path.remove(str(project_dir))


def load_current_stack():
    install_pyframework_stub()
    clear_src_modules()
    sys.path.insert(0, str(CURRENT_MODEL_DIR))
    try:
        model_module = importlib.import_module("src.model")
        utils_module = importlib.import_module("src.utils")
        return model_module.MCTPMatchingModel, utils_module.create_features_dataset
    finally:
        sys.path.remove(str(CURRENT_MODEL_DIR))


def to_python_scalar(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    return value


def build_input_dataframe(initial_data: dict) -> pd.DataFrame:
    input_df = pd.DataFrame(
        {
            "id_sd": [initial_data["UID"]],
            "ОФОРМЛЕНО": [initial_data["sdDt"]],
            "К2!_Описание": [initial_data["sdText"]],
            "Путь прохождения": [initial_data["pathTree"]],
        }
    )
    input_df["ОФОРМЛЕНО"] = pd.to_datetime(input_df["ОФОРМЛЕНО"], errors="coerce")

    return input_df[
        input_df["К2!_Описание"].notna()
        & (input_df["К2!_Описание"] != "None")
        & (input_df["К2!_Описание"] != "")
        & (
            ~input_df["К2!_Описание"].str.contains(
                "Отображение конфиденциальной информации", na=False
            )
        )
    ]


def features_dataset_to_intermediate(initial_data: dict, features_dataset: pd.DataFrame) -> dict:
    payload = {
        "UID": initial_data["UID"],
        "sdDt": initial_data["sdDt"],
        "sdText": initial_data["sdText"],
        "candidates": [],
    }

    if features_dataset is None or len(features_dataset) == 0:
        return payload

    for idx, (_, row) in enumerate(features_dataset.iterrows()):
        problem = to_python_scalar(row["problem"])
        model_features = {"problem": problem}
        for feature in CATBOOST_FEATURE_KEYS:
            model_features[feature] = to_python_scalar(row[feature])

        payload["candidates"].append(
            {
                "problemID": problem,
                "CandidateSDID": f"{initial_data['UID']}-{idx + 1}",
                "problemDescription": to_python_scalar(row["desc_candidate_problem"]),
                "problemTopic": to_python_scalar(row["theme_problem"]),
                "solvingProblem": to_python_scalar(row["decision_problem"]),
                "modelFeatures": model_features,
            }
        )

    return payload


async def build_preprocessed_payload(current_model, create_features_dataset, initial_data: dict) -> dict:
    input_df = build_input_dataframe(initial_data)
    if len(input_df) == 0:
        return features_dataset_to_intermediate(initial_data, pd.DataFrame())

    for column in current_model.df.columns:
        if column not in current_model.sd_new_col_list:
            input_df[column] = np.nan

    tmp_df = current_model.df.copy()
    tmp_df = pd.concat([tmp_df, input_df], ignore_index=True)
    results, _ = await current_model.main_pipeline(
        tmp_df, input_df, current_model.num_weeks, current_model.current_problems_list
    )

    if len(results) == 0:
        return features_dataset_to_intermediate(initial_data, pd.DataFrame())

    features_dataset = create_features_dataset(results)
    return features_dataset_to_intermediate(initial_data, features_dataset)


def build_cases(current_model, count: int = 3) -> list[dict]:
    df = current_model.df[
        current_model.df["К2!_Описание"].notna()
        & current_model.df["Путь прохождения"].notna()
    ].copy()
    df = df.sort_values("ОФОРМЛЕНО").tail(120)
    indexes = [0, len(df) // 2, len(df) - 1][:count]
    sd_dt = pd.to_datetime(current_model.df["ОФОРМЛЕНО"]).max() + timedelta(days=1)

    cases = []
    for offset, row_index in enumerate(indexes):
        row = df.iloc[row_index]
        cases.append(
            {
                "UID": 900000000 + offset,
                "sdDt": sd_dt.date().isoformat(),
                "sdText": str(row["К2!_Описание"])[:3000],
                "pathTree": str(row["Путь прохождения"])[:3000],
            }
        )
    return cases


def responses_equal(left: Any, right: Any, rel_tol: float = 1e-12) -> bool:
    if isinstance(left, dict) and isinstance(right, dict):
        if left.keys() != right.keys():
            return False
        return all(responses_equal(left[key], right[key], rel_tol) for key in left)
    if isinstance(left, list) and isinstance(right, list):
        if len(left) != len(right):
            return False
        return all(
            responses_equal(left_item, right_item, rel_tol)
            for left_item, right_item in zip(left, right)
        )
    if isinstance(left, (float, np.floating)) or isinstance(right, (float, np.floating)):
        try:
            if math.isnan(float(left)) and math.isnan(float(right)):
                return True
            return math.isclose(float(left), float(right), rel_tol=rel_tol, abs_tol=rel_tol)
        except (TypeError, ValueError):
            return False
    return left == right
