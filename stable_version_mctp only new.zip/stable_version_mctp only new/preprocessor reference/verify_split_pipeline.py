import asyncio
import json
import os

from split_tools import (
    CURRENT_MODEL_DIR,
    NEW_MODEL_DIR,
    PREPROCESSED_JSON_PATH,
    build_cases,
    build_preprocessed_payload,
    load_current_stack,
    load_model_class,
    responses_equal,
)


async def main() -> None:
    CurrentModel, create_features_dataset = load_current_stack()
    os.environ["STATIC_FILES_DIR"] = str(CURRENT_MODEL_DIR / "src" / "static")
    current_model = CurrentModel()

    NewModel = load_model_class(NEW_MODEL_DIR)
    os.environ["STATIC_FILES_DIR"] = str(NEW_MODEL_DIR / "src" / "static")
    new_model = NewModel()

    report = []
    for case in build_cases(current_model):
        current_response = await current_model.predict(case)
        preprocessed_payload = await build_preprocessed_payload(
            current_model, create_features_dataset, case
        )
        PREPROCESSED_JSON_PATH.write_text(
            json.dumps(preprocessed_payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        new_response = await new_model.predict(preprocessed_payload)

        ok = responses_equal(current_response, new_response)
        item = {
            "UID": case["UID"],
            "candidates": len(preprocessed_payload["candidates"]),
            "current_problems": len(current_response["problems"]),
            "new_problems": len(new_response["problems"]),
            "ok": ok,
            "current_response": current_response,
            "new_response": new_response,
        }
        report.append(item)
        if not ok:
            raise AssertionError(json.dumps(item, ensure_ascii=False, indent=2, default=str))

    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    asyncio.run(main())
