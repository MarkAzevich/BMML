from __future__ import annotations

import argparse
import json
import shutil
import zipfile
from collections import OrderedDict
from pathlib import Path
import xml.etree.ElementTree as ET


TOOL_ROOT = Path(__file__).resolve().parent
INPUT_DIR = TOOL_ROOT / "input"
OUTPUT_DIR = TOOL_ROOT / "output"

OUTPUT_FILENAMES = {
    "filter_common": "glossary_filter_additional_info.txt",
    "generation_common": "glossary_generation_common_info.txt",
    "generation_memo": "glossary_generation_memo_info.json",
    "filter_memo": "glossary_filter_memo_info.json",
}

KNOWN_STATIC_DIRS = [
    TOOL_ROOT.parent / "sledopyt-rag-dev-v0.17.2" / "src" / "static",
    TOOL_ROOT.parent / "dev_17_2" / "src" / "static",
]

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

EXPECTED_HEADERS = {
    "A": "id",
    "B": "Тип",
    "C": "Тип правила",
    "F": "Номер памятки",
    "G": "Подсказка",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Собирает glossary-файлы из Excel по той же логике, что и старый build_glossary_from_excel.ps1."
    )
    parser.add_argument(
        "--excel",
        type=Path,
        default=None,
        help="Путь к исходному .xlsx. Если не задан, берется самый свежий .xlsx из input/.",
    )
    parser.add_argument(
        "--sheet",
        type=str,
        default=None,
        help="Имя листа. Если не задано, скрипт сам находит нужный лист по заголовкам.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=OUTPUT_DIR,
        help="Папка, куда будут записаны 4 итоговых glossary-файла.",
    )
    parser.add_argument(
        "--sync-static",
        action="store_true",
        help="Дополнительно скопировать собранные файлы в известные src/static для dev_17_2 и GitHub 17.2.",
    )
    return parser.parse_args()


def normalize_text(value: str | None) -> str:
    if value is None:
        return ""
    value = str(value).replace("\r", "")
    lines: list[str] = []
    for line in value.split("\n"):
        stripped = line.strip()
        if stripped:
            lines.append(stripped)
    return "\n".join(lines).strip()


def get_latest_excel(input_dir: Path) -> Path:
    input_dir.mkdir(parents=True, exist_ok=True)
    candidates = [path for path in input_dir.iterdir() if path.is_file() and path.suffix.lower() == ".xlsx"]
    if not candidates:
        raise FileNotFoundError(f"В папке {input_dir} не найдено ни одного .xlsx файла.")
    return max(candidates, key=lambda path: path.stat().st_mtime)


def get_shared_strings(zip_file: zipfile.ZipFile) -> list[str]:
    try:
        root = ET.fromstring(zip_file.read("xl/sharedStrings.xml"))
    except KeyError:
        return []

    values: list[str] = []
    for item in root:
        parts = [node.text or "" for node in item.iter(f"{{{NS_MAIN}}}t")]
        values.append("".join(parts))
    return values


def get_sheet_targets(zip_file: zipfile.ZipFile) -> list[tuple[str, str]]:
    workbook_root = ET.fromstring(zip_file.read("xl/workbook.xml"))
    rels_root = ET.fromstring(zip_file.read("xl/_rels/workbook.xml.rels"))
    rel_map = {rel.attrib.get("Id"): rel.attrib.get("Target") for rel in rels_root}

    sheets_root = workbook_root.find(f"{{{NS_MAIN}}}sheets")
    if sheets_root is None:
        raise ValueError("В книге не найдено ни одного листа.")

    targets: list[tuple[str, str]] = []
    for sheet in sheets_root:
        name = sheet.attrib.get("name", "")
        rel_id = sheet.attrib.get(f"{{{NS_REL}}}id", "")
        target = rel_map.get(rel_id)
        if name and target:
            targets.append((name, target))
    return targets


def get_cell_column(cell_reference: str) -> str:
    return "".join(character for character in cell_reference if character.isalpha())


def get_cell_value(cell: ET.Element, shared_strings: list[str]) -> str:
    cell_type = cell.attrib.get("t", "")
    if cell_type == "inlineStr":
        return "".join(node.text or "" for node in cell.iter(f"{{{NS_MAIN}}}t"))

    value_node = cell.find(f"{{{NS_MAIN}}}v")
    if value_node is None or value_node.text is None:
        return ""

    raw_value = value_node.text
    if cell_type == "s" and raw_value.isdigit():
        return shared_strings[int(raw_value)]
    return raw_value


def import_sheet_rows(path: Path, sheet_name: str) -> list[dict[str, str]]:
    with zipfile.ZipFile(path) as zip_file:
        shared_strings = get_shared_strings(zip_file)
        target_path = None
        for candidate_name, candidate_target in get_sheet_targets(zip_file):
            if candidate_name == sheet_name:
                target_path = candidate_target
                break

        if target_path is None:
            raise ValueError(f"Лист '{sheet_name}' не найден в файле '{path.name}'.")

        sheet_root = ET.fromstring(zip_file.read(f"xl/{target_path}"))
        sheet_data = sheet_root.find(f"{{{NS_MAIN}}}sheetData")
        if sheet_data is None:
            return []

        rows: list[dict[str, str]] = []
        for row in sheet_data:
            row_item: dict[str, str] = {"_row": row.attrib.get("r", "")}
            for cell in row:
                row_item[get_cell_column(cell.attrib.get("r", ""))] = get_cell_value(cell, shared_strings)
            rows.append(row_item)
        return rows


def detect_glossary_sheet(path: Path) -> str:
    with zipfile.ZipFile(path) as zip_file:
        shared_strings = get_shared_strings(zip_file)
        for sheet_name, target_path in get_sheet_targets(zip_file):
            sheet_root = ET.fromstring(zip_file.read(f"xl/{target_path}"))
            sheet_data = sheet_root.find(f"{{{NS_MAIN}}}sheetData")
            if sheet_data is None or len(sheet_data) == 0:
                continue

            first_row = list(sheet_data)[0]
            header_map: dict[str, str] = {}
            for cell in first_row:
                column = get_cell_column(cell.attrib.get("r", ""))
                header_map[column] = normalize_text(get_cell_value(cell, shared_strings))

            if all(header_map.get(column) == expected for column, expected in EXPECTED_HEADERS.items()):
                return sheet_name

    raise ValueError(
        f"Не удалось автоматически определить лист с glossary-правилами в '{path.name}'. "
        "Не найдены ожидаемые заголовки в колонках A/B/C/F/G."
    )


def get_memo_ids(value: str | None) -> list[str]:
    normalized = normalize_text(value)
    if not normalized:
        return []

    memo_ids: list[str] = []
    for part in normalized.replace(";", ",").split(","):
        candidate = part.strip()
        if candidate.endswith(".0"):
            candidate = candidate[:-2]
        if candidate.isdigit() and candidate not in memo_ids:
            memo_ids.append(candidate)
    return memo_ids


def add_rule(mapping: dict[str, list[str]], memo_id: str, rule_text: str) -> None:
    if not memo_id or not rule_text:
        return
    mapping.setdefault(memo_id, [])
    if rule_text not in mapping[memo_id]:
        mapping[memo_id].append(rule_text)


def format_rule_list(rules: list[str]) -> str:
    return "\n".join(f"{index}. {rule}" for index, rule in enumerate(rules, start=1))


def convert_rule_mapping(mapping: dict[str, list[str]]) -> OrderedDict[str, str]:
    ordered: OrderedDict[str, str] = OrderedDict()
    for memo_id in sorted(mapping.keys(), key=lambda value: int(value)):
        ordered[memo_id] = format_rule_list(mapping[memo_id])
    return ordered


def build_glossary_payload(rows: list[dict[str, str]]) -> dict[str, object]:
    if not rows:
        raise ValueError("В выбранном листе не найдено ни одной строки.")

    common_rules: list[str] = []
    generation_memo_rules: dict[str, list[str]] = {}
    filter_memo_rules: dict[str, list[str]] = {}

    for row in rows[1:]:
        rule_class = normalize_text(row.get("B", ""))
        rule_type = normalize_text(row.get("C", ""))
        memo_cell = normalize_text(row.get("F", ""))
        hint = normalize_text(row.get("G", ""))

        if not hint:
            continue

        if rule_class == "0":
            if hint not in common_rules:
                common_rules.append(hint)
        elif rule_class == "1":
            for memo_id in get_memo_ids(memo_cell):
                add_rule(filter_memo_rules, memo_id, hint)
        elif rule_class == "2":
            for memo_id in get_memo_ids(memo_cell):
                add_rule(generation_memo_rules, memo_id, hint)
        elif rule_class or rule_type:
            raise ValueError(
                f"Неизвестный класс правила '{rule_class}' / тип '{rule_type}' в строке {row.get('_row', '?')}."
            )

    common_rules_text = format_rule_list(common_rules)
    generation_rules_json = convert_rule_mapping(generation_memo_rules)
    filter_rules_json = convert_rule_mapping(filter_memo_rules)

    return {
        "filter_common": common_rules_text,
        "generation_common": common_rules_text,
        "generation_memo": generation_rules_json,
        "filter_memo": filter_rules_json,
    }


def ensure_clean_directory(directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    for child in directory.iterdir():
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()


def write_payload(output_dir: Path, payload: dict[str, object]) -> dict[str, Path]:
    ensure_clean_directory(output_dir)

    paths = {name: output_dir / filename for name, filename in OUTPUT_FILENAMES.items()}
    paths["filter_common"].write_text(f"{payload['filter_common']}\n" if payload["filter_common"] else "", encoding="utf-8")
    paths["generation_common"].write_text(
        f"{payload['generation_common']}\n" if payload["generation_common"] else "",
        encoding="utf-8",
    )
    paths["generation_memo"].write_text(
        json.dumps(payload["generation_memo"], ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    paths["filter_memo"].write_text(
        json.dumps(payload["filter_memo"], ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return paths


def sync_static_files(source_paths: dict[str, Path]) -> list[Path]:
    synced: list[Path] = []
    for static_dir in KNOWN_STATIC_DIRS:
        static_dir.mkdir(parents=True, exist_ok=True)
        for key, source_path in source_paths.items():
            target_path = static_dir / OUTPUT_FILENAMES[key]
            shutil.copyfile(source_path, target_path)
            synced.append(target_path)
    return synced


def count_numbered_lines(text: str) -> int:
    return len([line for line in text.splitlines() if line.strip()])


def main() -> None:
    args = parse_args()

    excel_path = args.excel.resolve() if args.excel else get_latest_excel(INPUT_DIR)
    if not excel_path.exists():
        raise FileNotFoundError(f"Excel-файл не найден: {excel_path}")

    sheet_name = args.sheet or detect_glossary_sheet(excel_path)
    rows = import_sheet_rows(excel_path, sheet_name)
    payload = build_glossary_payload(rows)
    output_paths = write_payload(args.output_dir.resolve(), payload)

    print(f"Excel: {excel_path}")
    print(f"Лист: {sheet_name}")
    print(f"Строк данных: {max(len(rows) - 1, 0)}")
    print(f"Общие правила: {count_numbered_lines(str(payload['filter_common']))}")
    print(f"Памяток с generation-правилами: {len(payload['generation_memo'])}")
    print(f"Памяток с filter-правилами: {len(payload['filter_memo'])}")

    for key in ("filter_common", "generation_common", "generation_memo", "filter_memo"):
        print(f"Сохранено: {output_paths[key]}")

    if args.sync_static:
        synced_paths = sync_static_files(output_paths)
        for path in synced_paths:
            print(f"Обновлено: {path}")


if __name__ == "__main__":
    main()
