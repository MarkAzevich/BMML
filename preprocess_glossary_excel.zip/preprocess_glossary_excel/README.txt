Папка для простого обновления glossary-файлов из Excel.

Структура:
- `process_glossary_excel.py` — основной запускатор
- `input` — сюда кладешь `.xlsx` с правилами глоссария
- `output` — сюда скрипт складывает 4 готовых файла

Как запускать:
1. Положи Excel-файл в папку `input`
2. Запусти:
   `python process_glossary_excel.py`

Если хочешь явно указать файл:
`python process_glossary_excel.py --excel "C:\полный\путь\к\файлу.xlsx"`

Если хочешь еще и сразу обновить glossary-файлы в `dev_17_2` и `sledopyt-rag-dev-v0.17.2`:
`python process_glossary_excel.py --sync-static`

Что появляется в `output`:
- `glossary_filter_additional_info.txt`
- `glossary_generation_common_info.txt`
- `glossary_generation_memo_info.json`
- `glossary_filter_memo_info.json`

Что важно:
- логика генерации повторяет старый `build_glossary_from_excel.ps1`
- лист можно не указывать: скрипт сам ищет нужный лист по заголовкам
- если в Excel несколько листов, будет выбран тот, где есть колонки `id`, `Тип`, `Тип правила`, `Номер памятки`, `Подсказка`

Текущий рабочий сценарий:
- кладешь новый glossary Excel в `input`
- запускаешь `process_glossary_excel.py`
- забираешь готовые 4 файла из `output`
